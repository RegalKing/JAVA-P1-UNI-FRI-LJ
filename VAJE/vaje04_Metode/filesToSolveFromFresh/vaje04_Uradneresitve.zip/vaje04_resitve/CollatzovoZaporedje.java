
import java.util.Scanner;

public class CollatzovoZaporedje {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int spMeja = sc.nextInt();
        int zgMeja = sc.nextInt();

        int najDolzina = 0;
        int najZacetek = 0;

        for (int stevilo = spMeja;  stevilo <= zgMeja;  stevilo++) {
            int dolzina = dolzinaZaporedja(stevilo);

            if (dolzina > najDolzina) {
                najDolzina = dolzina;
                najZacetek = stevilo;
            }
        }

        System.out.println(najZacetek);
        System.out.println(najDolzina);
    }

    // Vrne dolžino Collatzovega zaporedja, ki izhaja iz podanega števila.
    public static int dolzinaZaporedja(int stevilo) {
        int dolzina = 1;
        while (stevilo > 1) {
            if (stevilo % 2 == 0) {
                stevilo /= 2;
            } else {
                stevilo = 3 * stevilo + 1;
            }
            dolzina++;
        }
        return dolzina;
    }
}

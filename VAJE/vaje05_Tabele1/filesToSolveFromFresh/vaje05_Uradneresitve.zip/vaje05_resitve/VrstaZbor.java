
import java.util.Scanner;

public class VrstaZbor {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int stVojakov = sc.nextInt();

        // preberi višine vojakov
        int[] visine = new int[stVojakov];
        for (int i = 0;  i < stVojakov;  i++) {
            visine[i] = sc.nextInt();
        }

        // izpiši indekse lokalno pravilno postavljenih (oziroma NOBEDEN)
        boolean vsajEden = false;
        for (int i = 0;  i < visine.length;  i++) {
            if (lokalnoPravilno(visine, i)) {
                System.out.println(i);
                vsajEden = true;
            }
        }
        if (!vsajEden) {
            System.out.println("NOBEDEN");
        }
    }

    /*
     * Vrne true natanko v primeru, če je element tabele <t> na indeksu <ix>
     * večji ali enak kot njegov levi sosed in hkrati manjši ali enak kot
     * njegov desni sosed.
     */
    private static boolean lokalnoPravilno(int[] t, int ix) {
        return (ix == 0 || t[ix] >= t[ix - 1]) && 
               (ix == t.length - 1 || t[ix] <= t[ix + 1]);
    }
}


import java.util.Scanner;

public class Anka {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int d = sc.nextInt();
        int stKombinacij = 0;
        for (int prva = 1;  prva <= 9;  prva += 2) {
            for (int druga = m + 1;  druga <= 9;  druga++) {
                for (int tretja = 0;  tretja <= 9;  tretja += d) {
                    System.out.printf("%d-%d-%d%n", prva, druga, tretja);
                    stKombinacij++;
                }
            }
        }
        System.out.println(stKombinacij);
    }
}

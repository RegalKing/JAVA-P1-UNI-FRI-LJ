
import java.util.Scanner;

public class Zgoscenke {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int stZgoscenk = sc.nextInt();
        int kapacitetaZgoscenke = sc.nextInt();

        int zasedenostZgoscenke = 0;   // zasedenost trenutne zgoščenke
        int stevilkaZgoscenke = 1;     // zaporedna številka trenutne zgoščenke

        while (sc.hasNextInt() && stevilkaZgoscenke <= stZgoscenk) {
            int velikostDatoteke = sc.nextInt();

            if (velikostDatoteke + zasedenostZgoscenke > kapacitetaZgoscenke) {
                // datoteke ne moremo shraniti na trenutno zgoščenko, zato
                // vzamemo novo
                stevilkaZgoscenke++;
                zasedenostZgoscenke = velikostDatoteke;

            } else {
                // datoteko lahko shranimo na trenutno zgoščenko
                zasedenostZgoscenke += velikostDatoteke;
            }

            if (stevilkaZgoscenke <= stZgoscenk) {
                System.out.printf("%d EP -> zgoscenka %d (%d EP)%n",
                        velikostDatoteke, stevilkaZgoscenke, zasedenostZgoscenke);
            }
        }
    }
}


import java.util.Scanner;

public class Piramida {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int visina = sc.nextInt();
        int pr = visina - 1;   // število presledkov v trenutni vrstici
        int zv = 1;            // število zvezdic v trenutni vrstici
        for (int i = 1;  i <= visina;  i++) {
            for (int j = 1;  j <= pr;  j++) {
                System.out.print(" ");
            }
            for (int j = 1;  j <= zv;  j++) {
                System.out.print("*");
            }
            System.out.println();
            pr--;
            zv += 2;
        }
    }
}

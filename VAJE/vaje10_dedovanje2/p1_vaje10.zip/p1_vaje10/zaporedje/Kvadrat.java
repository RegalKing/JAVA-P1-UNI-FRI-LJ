
public class Kvadrat extends Zaporedje {

    @Override
    public Integer y(int x) {
        return x * x;
    }
}

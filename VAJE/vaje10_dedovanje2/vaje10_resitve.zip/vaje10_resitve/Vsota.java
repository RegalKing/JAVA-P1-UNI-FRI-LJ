
/*
 * Objekt tega razreda bomo vrnili kot rezultat metode <vsota> v razredu
 * Zaporedje.
 */

public class Vsota extends Zaporedje {

    private Zaporedje prvo;
    private Zaporedje drugo;

    public Vsota(Zaporedje prvo, Zaporedje drugo) {
        this.prvo = prvo;
        this.drugo = drugo;
    }

    @Override
    public Integer y(int x) {
        if (this.prvo.y(x) == null || this.drugo.y(x) == null) {
            return null;
        }
        return this.prvo.y(x) + this.drugo.y(x);
        // Integer.valueOf(this.prvo.y(x).intValue() + this.drugo.y(x).intValue())
    }
}

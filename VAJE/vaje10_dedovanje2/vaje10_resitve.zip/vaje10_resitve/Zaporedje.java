
public abstract class Zaporedje {

    public abstract Integer y(int x);

    public String vNiz(Interval interval) {
        StringBuilder sb = new StringBuilder("[");
        int zacetek = interval.vrniZacetek();
        int konec = interval.vrniKonec();
        boolean prvic = true;
        for (int x = zacetek;  x <= konec;  x++) {
            Integer y = this.y(x);
            if (y != null) {
                if (!prvic) {
                    sb.append(", ");
                }
                prvic = false;
                sb.append(String.format("%d -> %d", x, y));
            }
        }
        sb.append("]");
        return sb.toString();
    }

    public Interval minMax(Interval interval) {
        // Sprehodimo se po intervalu in vzdržujemo dosedanji minimum in
        // maksimum vrednosti y, pri tem pa preskakujemo elemente null.
        int zacetek = interval.vrniZacetek();
        int konec = interval.vrniKonec();
        Integer min = null;
        Integer max = null;
        for (int x = zacetek;  x <= konec;  x++) {
            Integer y = this.y(x);
            if (y != null) {
                min = (min == null) ? (y) : (Math.min(min, y));
                max = (max == null) ? (y) : (Math.max(max, y));
            }
        }
        return new Interval(min, max);
    }

    public boolean jeMonotono(Interval interval) {
        // zaporedje je monotono, kadar je monotono naraščajoče ali monotono
        // padajoče
        return this.jeMonotono(interval, 1) || this.jeMonotono(interval, -1);
    }

    // Vrne true natanko v primeru, če je zaporedje this na podanem intervalu
    // monotono naraščajoče (smer == 1) oziroma monotono padajoče (smer == -1).
    private boolean jeMonotono(Interval interval, int smer) {
        int zacetek = interval.vrniZacetek();
        int konec = interval.vrniKonec();
        Integer yp = null;   // prejšnja veljavna vrednost y

        for (int x = zacetek;  x <= konec;  x++) {
            Integer y = this.y(x);
            if (y != null) {
                if (yp != null && y * smer <= yp * smer) {
                    return false;
                }
                yp = y;
            }
        }
        return true;
    }

    public Zaporedje vsota(Zaporedje drugo) {
        // Objekt abstraktnega razreda ustvarimo kot objekt podrazreda, v
        // katerem definiramo abstraktne metode.  V našem primeru bomo v
        // razredu Vsota definirali metodo y.  V tej metodi bomo potrebovali
        // obe izhodiščni zaporedji (this in drugo), zato ju objektu razreda
        // Vsota posredujemo ob njegovi izdelavi (torej prek konstruktorja).
        return new Vsota(this, drugo);
    }

    public Zaporedje inverz(Interval interval) {
        if (!this.jeMonotono(interval)) {
            return null;
        }
        return new Inverz(this, interval);
    }
}


/*
 * Objekt tega razreda bomo vrnili kot rezultat metode <inverz> v razredu
 * Zaporedje.
 */

public class Inverz extends Zaporedje {

    // zaporedje, za katero računamo inverz
    private Zaporedje izhodisce;

    // interval, za katerega računamo inverz
    private Interval interval;

    public Inverz(Zaporedje izhodisce, Interval interval) {
        this.izhodisce = izhodisce;
        this.interval = interval;
    }

    @Override
    public Integer y(int x) {
        // Poiščemo takšno točko i na intervalu this.interval, da velja
        // this.izhodisce.y(i) == x.
        int zacetek = this.interval.vrniZacetek();
        int konec = this.interval.vrniKonec();
        for (int i = zacetek;  i <= konec;  i++) {
            Integer y = this.izhodisce.y(i);
            if (y != null && y == x) {  // y.intValue() == x
                return i;
            }
        }
        return null;
    }
}

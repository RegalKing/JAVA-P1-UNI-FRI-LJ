
public class BesedilnaDatoteka extends Datoteka {

    private int stZnakov;

    public BesedilnaDatoteka(String ime, int stZnakov) {
        super(ime);   // klic konstruktorja razreda Datoteka
        this.stZnakov = stZnakov;
    }

    // Definiramo metodo opis.
    @Override
    public String opis() {
        return String.format("b %d", this.stZnakov);
    }

    // Definiramo metodo velikost.
    @Override
    public int velikost() {
        return this.stZnakov;
    }
}

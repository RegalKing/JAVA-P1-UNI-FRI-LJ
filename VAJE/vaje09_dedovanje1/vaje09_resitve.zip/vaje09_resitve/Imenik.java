
public class Imenik extends Datoteka {

    private static final int METAPODATKI = 256;

    // datoteke, ki jih vsebuje imenik this
    private Datoteka[] datoteke;

    public Imenik(String ime, Datoteka[] datoteke) {
        super(ime);
        this.datoteke = datoteke;
    }

    @Override
    public String opis() {
        return String.format("i %d", this.datoteke.length);
    }

    @Override
    public int velikost() {
        // seštejemo velikosti vseh datotek v imeniku this in prištejemo še
        // prostor, ki ga zasedajo metapodatki
        int rezultat = METAPODATKI;
        for (Datoteka datoteka: this.datoteke) {
            rezultat += datoteka.velikost();
        }
        return rezultat;
    }

    public int steviloVecjihSlik(int prag) {
        int stevec = 0;
        for (Datoteka datoteka: this.datoteke) {
            if (datoteka instanceof SlikovnaDatoteka) {
                // Pretvorbo tipa potrebujemo zato, da bomo lahko poklicali
                // metodo jeVelikaVsaj.  Prevajalnik namreč ne ve, da kazalec
                // <datoteka> kaže na objekt tipa SlikovnaDatoteka, saj vidi
                // le tip kazalca <datoteka>, ki je enak Datoteka.
                SlikovnaDatoteka slika = (SlikovnaDatoteka) datoteka;
                if (slika.jeVelikaVsaj(prag)) {
                    stevec++;
                }
            }
        }
        return stevec;
    }

    public String poisci(String ime) {
        return this.poisci(".", ime);
    }

    // pot: doslej zgrajena relativna pot od izhodiščnega imenika (imenika,
    // nad katerim smo poklicali zgornjo metodo poisci) do datoteke z imenom
    // <ime>
    private String poisci(String pot, String ime) {
        // išči neposredno v imeniku this
        for (Datoteka datoteka: this.datoteke) {
            if (datoteka.vrniIme().equals(ime)) {
                return (pot + "/" + ime);
            }
        }

        // išči v podimenikih
        for (Datoteka datoteka: this.datoteke) {
            if (datoteka instanceof Imenik) {
                Imenik imenik = (Imenik) datoteka;
                String rezultat = imenik.poisci(pot + "/" + imenik.vrniIme(), ime);
                if (rezultat != null) {
                    // datoteko smo našli, zato je ne iščemo več
                    return rezultat;
                }
            }
        }

        // datoteke nismo našli niti v imeniku this niti v njegovih
        // podimenikih
        return null;
    }
}


public class SlikovnaDatoteka extends Datoteka {

    private static final int METAPODATKI = 54;

    private int sirina;
    private int visina;

    public SlikovnaDatoteka(String ime, int sirina, int visina) {
        super(ime);
        this.sirina = sirina;
        this.visina = visina;
    }

    @Override
    public String opis() {
        return String.format("s %d x %d", this.sirina, this.visina);
    }

    @Override
    public int velikost() {
        return (3 * this.sirina * this.visina + METAPODATKI);
    }

    public boolean jeVelikaVsaj(int prag) {
        return (this.sirina >= prag && this.visina >= prag);
    }
}

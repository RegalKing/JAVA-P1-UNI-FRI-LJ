
/*
 * Izhodišče hierarhije; nadrazred razredov BesedilnaDatoteka,
 * SlikovnaDatoteka in Imenik
 */

public abstract class Datoteka {

    private String ime;

    // Konstruktor se bo klical zgolj v okviru konstruktorjev podrazredov. Ker
    // je razred abstrakten, ne moremo ustvarjati njegovih objektov.
    protected Datoteka(String ime) {
        this.ime = ime;
    }

    public String vrniIme() {
        return this.ime;
    }

    // Niz, ki ga vrne ta metoda, ima za vse razrede enako zgradbo,
    // razlikujejo se le opisi datotek (te zajamemo z metodo opis).
    public String toString() {
        return String.format("%s [%s]", this.ime, this.opis());
    }

    // Opis datoteke se za vsak tip določi po svoje.  Metodo bomo definirali v
    // podrazredih.
    public abstract String opis();

    // Velikost datoteke se za vsak tip izračuna po svoje.  Metodo bomo
    // definirali v podrazredih.
    public abstract int velikost();
}

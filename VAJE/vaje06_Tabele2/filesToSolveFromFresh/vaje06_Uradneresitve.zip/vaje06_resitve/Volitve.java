
public class Volitve {

    public static void main(String[] args) {
        // dopolnite po potrebi ...
    }

    public static int steviloGlasov(int[][][] t, int leto, int stranka) {
        // Seštejemo glasove, ki jih je stranka <stranka> v letu <leto>
        // prejela po posameznih voliščih.

        int rezultat = 0;
        for (int volisce = 0;  volisce < t[leto][stranka].length;  volisce++) {
            rezultat += t[leto][stranka][volisce];
        }
        return rezultat;
    }

    public static int[][] glasovi(int[][][] t) {
        // Za vsak par (leto, stranka) izračunamo število glasov, ki jih je
        // stranka <stranka> prejela v letu <leto>, in rezultat shranimo v
        // izhodno tabelo v celico (leto, stranka).

        int[][] rezultat = new int[t.length][t[0].length];
        for (int leto = 0;  leto < t.length;  leto++) {
            for (int stranka = 0;  stranka < t[leto].length;  stranka++) {
                rezultat[leto][stranka] = steviloGlasov(t, leto, stranka);
            }
        }
        return rezultat;
    }

    public static int najVolisce(int[][][] t, int stranka) {
        // Za vsako volišče izračunamo skupno število glasov, ki jih je
        // stranka <stranka> prejela v vseh dosedanjih letih, in poiščemo
        // volišče z največjo vsoto.

        int stVolisc = t[0][stranka].length;
        int najStGlasov = 0;
        int rezultat = 0;

        for (int volisce = 0;  volisce < stVolisc;  volisce++) {
            int stGlasov = 0;
            for (int leto = 0;  leto < t.length;  leto++) {
                stGlasov += t[leto][stranka][volisce];
            }
            if (stGlasov > najStGlasov) {
                najStGlasov = stGlasov;
                rezultat = volisce;
            }
        }
        return rezultat;
    }

    public static int vsotaUvrstitev(int[][][] t, int stranka, int volisce) {
        // Za vsako leto izračunamo uvrstitev, ki jo je stranka <stranka>
        // dosegla na volišču <volisce>, in dobljene uvrstitve seštejemo.

        int rezultat = 0;
        for (int leto = 0;  leto < t.length;  leto++) {
            // uvrstitev = 1 + število strogo uspešnejših strank v letu <leto> na volišču <volisce>
            int uvrstitev = 1;
            for (int s = 0;  s < t[leto].length;  s++) {
                if (t[leto][s][volisce] > t[leto][stranka][volisce]) {
                    uvrstitev++;
                }
            }
            rezultat += uvrstitev;
        }
        return rezultat;
    }
}

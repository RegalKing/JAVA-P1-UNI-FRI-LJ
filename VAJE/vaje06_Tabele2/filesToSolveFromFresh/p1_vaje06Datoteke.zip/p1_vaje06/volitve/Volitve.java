
public class Volitve {

    public static void main(String[] args) {
        // dopolnite po potrebi ...
    }

    public static int steviloGlasov(int[][][] t, int leto, int stranka) {
        // popravite / dopolnite
        return -1;
    }

    public static int[][] glasovi(int[][][] t) {
        // popravite / dopolnite
        return null;
    }

    public static int najVolisce(int[][][] t, int stranka) {
        // popravite / dopolnite
        return -1;
    }

    public static int vsotaUvrstitev(int[][][] t, int stranka, int volisce) {
        // popravite / dopolnite
        return -1;
    }
}


import java.util.*;

public class Glavni {

    public static void urediPoLetuInNaslovu(List<Clanek> clanki) {
        // dopolnite ...
    }

    public static Set<Avtor> vsiAvtorji(Collection<Clanek> clanki) {
        // popravite / dopolnite ...
        return null;
    }

    public static Map<Avtor, List<Clanek>> clankiPoAvtorjih(Collection<Clanek> clanki) {
        // popravite / dopolnite ...
        return null;
    }

    public static Avtor najplodnejsiAvtor(Collection<Clanek> clanki) {
        // popravite / dopolnite ...
        return null;
    }
}


import java.util.*;

public class Liga {

    private Collection<String> klubi;
    private Collection<Tekma> tekme;

    public Liga(Collection<String> klubi, Collection<Tekma> tekme) {
        this.klubi = klubi;
        this.tekme = tekme;
    }

    public int steviloTock(String klub) {
        // popravite / dopolnite ...
        return -1;
    }

    public Slovar<String, Integer> klub2tocke() {
        // popravite / dopolnite ...
        return null;
    }

    public List<String> lestvica() {
        // popravite / dopolnite ...
        return null;
    }

    public Iterator<Tekma> poTekmah(int minGR) {
        // popravite / dopolnite ...
        return null;
    }
}

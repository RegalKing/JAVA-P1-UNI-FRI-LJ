
import java.util.Scanner;

public class Romanje {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int celotnaPot = sc.nextInt();
        int prehodiPrviDan = sc.nextInt();
        int zmanjsevanje = sc.nextInt();
        
        int preostalaPot = celotnaPot;  // preostala pot na začetku trenutnega dne
        int prehodiTaDan = prehodiPrviDan;  // koliko prehodi v trenutnem dnevu
        int stDneva = 1;   // zaporedna številka trenutnega dne

        while (preostalaPot > 0 && prehodiTaDan > 0) {
            if (preostalaPot < prehodiTaDan) {
                prehodiTaDan = preostalaPot;
            }

            // preostala pot na koncu trenutnega dne
            int novaPreostalaPot = preostalaPot - prehodiTaDan;
            System.out.println(stDneva + ": " + preostalaPot + " -> " + novaPreostalaPot);

            preostalaPot = novaPreostalaPot;
            prehodiTaDan -= zmanjsevanje;
            stDneva++;
        }
    }
}

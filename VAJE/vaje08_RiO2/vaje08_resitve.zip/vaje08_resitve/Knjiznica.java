
public class Knjiznica {

    private int stClanov;
    private int stNaslovov;
    private int stIzvodovNaNaslov;

    // [c][n]: true natanko v primeru, če ima član c v izposoji izvod naslova n
    private boolean[][] imaClanNaslov;

    // [n]: število posojenih izvodov naslova n
    private int[] posojeniIzvodiNaslova;

    // [n]: kolikokrat je bil naslov n izposojen
    private int[] kolikokratNaslov;

    public Knjiznica(int stClanov, int stNaslovov, int stIzvodovNaNaslov) {
        this.stClanov = stClanov;
        this.stNaslovov = stNaslovov;
        this.stIzvodovNaNaslov = stIzvodovNaNaslov;
        this.posojeniIzvodiNaslova = new int[stNaslovov];
        this.imaClanNaslov = new boolean[stClanov][stNaslovov];
        this.kolikokratNaslov = new int[stNaslovov];
    }

    public boolean posodi(int clan, int naslov) {
        // preverimo, ali si podani član lahko izposodi izvod podanega naslova
        if (this.posojeniIzvodiNaslova[naslov] < this.stIzvodovNaNaslov && 
                !this.imaClanNaslov[clan][naslov]) {
            this.posojeniIzvodiNaslova[naslov]++;
            this.imaClanNaslov[clan][naslov] = true;
            this.kolikokratNaslov[naslov]++;
            return true;
        }
        return false;
    }

    public void clanVrne(int clan) {
        // član vrne izvode vseh naslovov, ki jih ima pri sebi
        for (int naslov = 0;  naslov < this.stNaslovov;  naslov++) {
            if (this.imaClanNaslov[clan][naslov]) {
                this.imaClanNaslov[clan][naslov] = false;
                this.posojeniIzvodiNaslova[naslov]--;
            }
        }
    }

    public int posojeni(int naslov) {
        return this.posojeniIzvodiNaslova[naslov];
    }

    public int priClanu(int clan) {
        // za vsak naslov preverimo, ali ima podani član njegov izvod
        int stIzvodov = 0;
        for (int naslov = 0;  naslov < this.stNaslovov;  naslov++) {
            if (this.imaClanNaslov[clan][naslov]) {
                stIzvodov++;
            }
        }
        return stIzvodov;
    }

    public int najNaslov() {
        int naj = 0;
        for (int naslov = 0;  naslov < this.stNaslovov;  naslov++) {
            if (this.kolikokratNaslov[naslov] > this.kolikokratNaslov[naj]) {
                naj = naslov;
            }
        }
        return naj;
    }
}

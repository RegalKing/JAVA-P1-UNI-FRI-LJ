
public class Fibonacci {

    // predprejšnje posplošeno Fibonaccijevo število
    private int predprejsnje;

    // prejšnje posplošeno Fibonaccijevo število
    private int prejsnje;

    public Fibonacci(int prvo, int drugo) {
        this.predprejsnje = prvo;
        this.prejsnje = drugo;
    }

    public int naslednji() {
        // izračunamo naslednje Fibonaccijevo število
        int trenutno = this.predprejsnje + this.prejsnje;

        // pripravimo se na naslednji klic metode <naslednji>
        this.predprejsnje = this.prejsnje;
        this.prejsnje = trenutno;
        return trenutno;
    }
}

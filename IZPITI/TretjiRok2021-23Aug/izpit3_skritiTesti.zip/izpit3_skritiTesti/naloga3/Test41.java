
public class Test41 {

    public static void main(String[] args) {
        Tretja.RodovniskiPes[] psi = new Tretja.RodovniskiPes[73];
        psi[0] = new Tretja.RodovniskiPes("babab", null, null);
        psi[1] = new Tretja.RodovniskiPes("babab", null, null);
        psi[2] = new Tretja.RodovniskiPes("babab", null, null);
        psi[3] = new Tretja.RodovniskiPes("babab", null, null);
        psi[4] = new Tretja.RodovniskiPes("babab", null, null);
        psi[5] = new Tretja.RodovniskiPes("babab", null, null);
        psi[6] = new Tretja.RodovniskiPes("babab", null, null);
        psi[7] = new Tretja.RodovniskiPes("babab", psi[4], psi[1]);
        psi[8] = new Tretja.RodovniskiPes("babab", null, null);
        psi[9] = new Tretja.RodovniskiPes("babab", null, null);
        psi[10] = new Tretja.RodovniskiPes("babab", null, null);
        psi[11] = new Tretja.RodovniskiPes("babab", null, null);
        psi[12] = new Tretja.RodovniskiPes("bab", null, null);
        psi[13] = new Tretja.RodovniskiPes("babab", null, null);
        psi[14] = new Tretja.RodovniskiPes("babab", null, null);
        psi[15] = new Tretja.RodovniskiPes("babab", null, null);
        psi[16] = new Tretja.RodovniskiPes("babab", null, null);
        psi[17] = new Tretja.RodovniskiPes("babab", null, null);
        psi[18] = new Tretja.RodovniskiPes("babab", psi[6], psi[10]);
        psi[19] = new Tretja.RodovniskiPes("babab", null, null);
        psi[20] = new Tretja.RodovniskiPes("babab", psi[13], psi[5]);
        psi[21] = new Tretja.RodovniskiPes("babab", null, null);
        psi[22] = new Tretja.RodovniskiPes("babab", psi[16], psi[12]);
        psi[23] = new Tretja.RodovniskiPes("babab", null, null);
        psi[24] = new Tretja.RodovniskiPes("babab", psi[11], psi[0]);
        psi[25] = new Tretja.RodovniskiPes("babab", null, null);
        psi[26] = new Tretja.RodovniskiPes("bab", psi[9], psi[20]);
        psi[27] = new Tretja.RodovniskiPes("babab", psi[21], psi[7]);
        psi[28] = new Tretja.RodovniskiPes("babab", psi[3], psi[25]);
        psi[29] = new Tretja.RodovniskiPes("babab", psi[14], psi[18]);
        psi[30] = new Tretja.RodovniskiPes("babab", null, null);
        psi[31] = new Tretja.RodovniskiPes("bab", psi[19], psi[15]);
        psi[32] = new Tretja.RodovniskiPes("babab", psi[30], psi[31]);
        psi[33] = new Tretja.RodovniskiPes("babab", psi[26], psi[27]);
        psi[34] = new Tretja.RodovniskiPes("babab", psi[28], psi[29]);
        psi[35] = new Tretja.RodovniskiPes("babab", psi[33], psi[17]);
        psi[36] = new Tretja.RodovniskiPes("babab", null, null);
        psi[37] = new Tretja.RodovniskiPes("babab", null, null);
        psi[38] = new Tretja.RodovniskiPes("babab", null, null);
        psi[39] = new Tretja.RodovniskiPes("babab", psi[8], psi[23]);
        psi[40] = new Tretja.RodovniskiPes("babab", null, null);
        psi[41] = new Tretja.RodovniskiPes("babab", psi[24], psi[37]);
        psi[42] = new Tretja.RodovniskiPes("babab", null, null);
        psi[43] = new Tretja.RodovniskiPes("babab", null, null);
        psi[44] = new Tretja.RodovniskiPes("babab", psi[36], psi[43]);
        psi[45] = new Tretja.RodovniskiPes("babab", psi[35], psi[39]);
        psi[46] = new Tretja.RodovniskiPes("babab", psi[41], psi[45]);
        psi[47] = new Tretja.RodovniskiPes("babab", psi[42], psi[40]);
        psi[48] = new Tretja.RodovniskiPes("babab", psi[44], psi[2]);
        psi[49] = new Tretja.RodovniskiPes("bab", psi[46], psi[32]);
        psi[50] = new Tretja.RodovniskiPes("babab", null, null);
        psi[51] = new Tretja.RodovniskiPes("babab", psi[48], psi[49]);
        psi[52] = new Tretja.RodovniskiPes("babab", psi[22], psi[51]);
        psi[53] = new Tretja.RodovniskiPes("babab", null, null);
        psi[54] = new Tretja.RodovniskiPes("babab", psi[50], psi[38]);
        psi[55] = new Tretja.RodovniskiPes("bab", psi[54], psi[34]);
        psi[56] = new Tretja.RodovniskiPes("babab", psi[55], psi[52]);
        psi[57] = new Tretja.RodovniskiPes("babab", psi[53], psi[47]);
        psi[58] = new Tretja.RodovniskiPes("babab", null, null);
        psi[59] = new Tretja.RodovniskiPes("babab", psi[57], psi[58]);
        psi[60] = new Tretja.RodovniskiPes("bab", null, null);
        psi[61] = new Tretja.RodovniskiPes("babab", null, null);
        psi[62] = new Tretja.RodovniskiPes("babab", null, null);
        psi[63] = new Tretja.RodovniskiPes("babab", psi[61], psi[59]);
        psi[64] = new Tretja.RodovniskiPes("babab", psi[60], psi[63]);
        psi[65] = new Tretja.RodovniskiPes("babab", psi[56], psi[62]);
        psi[66] = new Tretja.RodovniskiPes("babab", null, null);
        psi[67] = new Tretja.RodovniskiPes("babab", null, null);
        psi[68] = new Tretja.RodovniskiPes("babab", null, null);
        psi[69] = new Tretja.RodovniskiPes("babab", psi[66], psi[68]);
        psi[70] = new Tretja.RodovniskiPes("babab", psi[67], psi[64]);
        psi[71] = new Tretja.RodovniskiPes("babab", psi[69], psi[65]);
        psi[72] = new Tretja.RodovniskiPes("babab", null, null);

        for (int i = 0;  i < psi.length;  i++) {
            System.out.printf("psi[%d] -> %b%n", i, psi[i].preveri());
        }
    }
}


public class Test07 {

    public static void main(String[] args) {
        Tretja.RodovniskiPes[] psi = new Tretja.RodovniskiPes[29];
        psi[0] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[1] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[2] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[3] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[4] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[5] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[6] = new Tretja.RodovniskiPes("bb", null, null);
        psi[7] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[8] = new Tretja.RodovniskiPes("bb", null, null);
        psi[9] = new Tretja.RodovniskiPes("bb", null, null);
        psi[10] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[11] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[12] = new Tretja.RodovniskiPes("bb", null, null);
        psi[13] = new Tretja.RodovniskiPes("bb", null, null);
        psi[14] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[15] = new Tretja.RodovniskiPes("bb", null, null);
        psi[16] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[17] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[18] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[19] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[20] = new Tretja.RodovniskiPes("bb", null, null);
        psi[21] = new Tretja.RodovniskiPes("bb", null, null);
        psi[22] = new Tretja.RodovniskiPes("bb", null, null);
        psi[23] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[24] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[25] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[26] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[27] = new Tretja.RodovniskiPes("bbbbb", null, null);
        psi[28] = new Tretja.RodovniskiPes("bbbbb", null, null);

        System.out.println(Tretja.prestej(psi, "bb"));
        System.out.println(Tretja.prestej(psi, "bbbbb"));
    }
}


public class Test10 {

    public static void main(String[] args) {
        Tretja.RodovniskiPes[] psi = new Tretja.RodovniskiPes[62];
        psi[0] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[1] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[2] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[3] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[4] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[5] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[6] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[7] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[8] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[9] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[10] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[11] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[12] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[13] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[14] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[15] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[16] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[17] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[18] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[19] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[20] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[21] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[22] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[23] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[24] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[25] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[26] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[27] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[28] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[29] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[30] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[31] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[32] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[33] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[34] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[35] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[36] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[37] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[38] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[39] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[40] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[41] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[42] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[43] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[44] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[45] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[46] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[47] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[48] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[49] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[50] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[51] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[52] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[53] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[54] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[55] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[56] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[57] = new Tretja.RodovniskiPes("abbab", null, null);
        psi[58] = new Tretja.RodovniskiPes("bbbab", null, null);
        psi[59] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[60] = new Tretja.RodovniskiPes("aabb", null, null);
        psi[61] = new Tretja.RodovniskiPes("abbab", null, null);

        System.out.println(Tretja.prestej(psi, "bbbab"));
        System.out.println(Tretja.prestej(psi, "aabb"));
        System.out.println(Tretja.prestej(psi, "abbab"));
    }
}


public class Test38 {

    public static void main(String[] args) {
        Tretja.RodovniskiPes[] psi = new Tretja.RodovniskiPes[73];
        psi[0] = new Tretja.RodovniskiPes("ab", null, null);
        psi[1] = new Tretja.RodovniskiPes("ab", null, null);
        psi[2] = new Tretja.RodovniskiPes("ab", psi[0], psi[1]);
        psi[3] = new Tretja.RodovniskiPes("ab", null, null);
        psi[4] = new Tretja.RodovniskiPes("ab", null, null);
        psi[5] = new Tretja.RodovniskiPes("ab", psi[4], psi[2]);
        psi[6] = new Tretja.RodovniskiPes("bba", psi[3], psi[5]);
        psi[7] = new Tretja.RodovniskiPes("ab", null, null);
        psi[8] = new Tretja.RodovniskiPes("ab", null, null);
        psi[9] = new Tretja.RodovniskiPes("ab", psi[8], psi[6]);
        psi[10] = new Tretja.RodovniskiPes("ab", null, null);
        psi[11] = new Tretja.RodovniskiPes("ab", psi[10], psi[7]);
        psi[12] = new Tretja.RodovniskiPes("ab", psi[11], psi[9]);
        psi[13] = new Tretja.RodovniskiPes("ab", null, null);
        psi[14] = new Tretja.RodovniskiPes("ab", null, null);
        psi[15] = new Tretja.RodovniskiPes("ab", null, null);
        psi[16] = new Tretja.RodovniskiPes("ab", null, null);
        psi[17] = new Tretja.RodovniskiPes("bba", psi[12], psi[15]);
        psi[18] = new Tretja.RodovniskiPes("ab", null, null);
        psi[19] = new Tretja.RodovniskiPes("bba", psi[14], psi[18]);
        psi[20] = new Tretja.RodovniskiPes("ab", psi[13], psi[19]);
        psi[21] = new Tretja.RodovniskiPes("ab", psi[17], psi[16]);
        psi[22] = new Tretja.RodovniskiPes("ab", psi[21], psi[20]);
        psi[23] = new Tretja.RodovniskiPes("ab", null, null);
        psi[24] = new Tretja.RodovniskiPes("ab", null, null);
        psi[25] = new Tretja.RodovniskiPes("ab", psi[24], psi[23]);
        psi[26] = new Tretja.RodovniskiPes("ab", psi[22], psi[25]);
        psi[27] = new Tretja.RodovniskiPes("ab", null, null);
        psi[28] = new Tretja.RodovniskiPes("ab", null, null);
        psi[29] = new Tretja.RodovniskiPes("ab", psi[28], psi[26]);
        psi[30] = new Tretja.RodovniskiPes("ab", psi[27], psi[29]);
        psi[31] = new Tretja.RodovniskiPes("ab", null, null);
        psi[32] = new Tretja.RodovniskiPes("ab", null, null);
        psi[33] = new Tretja.RodovniskiPes("ab", null, null);
        psi[34] = new Tretja.RodovniskiPes("ab", psi[30], psi[33]);
        psi[35] = new Tretja.RodovniskiPes("ab", psi[31], psi[32]);
        psi[36] = new Tretja.RodovniskiPes("ab", null, null);
        psi[37] = new Tretja.RodovniskiPes("bba", psi[34], psi[35]);
        psi[38] = new Tretja.RodovniskiPes("bba", psi[36], psi[37]);
        psi[39] = new Tretja.RodovniskiPes("ab", null, null);
        psi[40] = new Tretja.RodovniskiPes("ab", psi[38], psi[39]);
        psi[41] = new Tretja.RodovniskiPes("ab", null, null);
        psi[42] = new Tretja.RodovniskiPes("ab", psi[40], psi[41]);
        psi[43] = new Tretja.RodovniskiPes("ab", null, null);
        psi[44] = new Tretja.RodovniskiPes("ab", psi[43], psi[42]);
        psi[45] = new Tretja.RodovniskiPes("ab", null, null);
        psi[46] = new Tretja.RodovniskiPes("ab", null, null);
        psi[47] = new Tretja.RodovniskiPes("ab", psi[46], psi[45]);
        psi[48] = new Tretja.RodovniskiPes("bba", psi[44], psi[47]);
        psi[49] = new Tretja.RodovniskiPes("ab", null, null);
        psi[50] = new Tretja.RodovniskiPes("bba", psi[48], psi[49]);
        psi[51] = new Tretja.RodovniskiPes("ab", null, null);
        psi[52] = new Tretja.RodovniskiPes("ab", null, null);
        psi[53] = new Tretja.RodovniskiPes("ab", psi[52], psi[50]);
        psi[54] = new Tretja.RodovniskiPes("ab", psi[51], psi[53]);
        psi[55] = new Tretja.RodovniskiPes("ab", null, null);
        psi[56] = new Tretja.RodovniskiPes("ab", psi[54], psi[55]);
        psi[57] = new Tretja.RodovniskiPes("ab", null, null);
        psi[58] = new Tretja.RodovniskiPes("ab", null, null);
        psi[59] = new Tretja.RodovniskiPes("ab", psi[57], psi[58]);
        psi[60] = new Tretja.RodovniskiPes("ab", null, null);
        psi[61] = new Tretja.RodovniskiPes("ab", psi[56], psi[59]);
        psi[62] = new Tretja.RodovniskiPes("bba", null, null);
        psi[63] = new Tretja.RodovniskiPes("ab", psi[62], psi[60]);
        psi[64] = new Tretja.RodovniskiPes("ab", psi[63], psi[61]);
        psi[65] = new Tretja.RodovniskiPes("ab", null, null);
        psi[66] = new Tretja.RodovniskiPes("ab", null, null);
        psi[67] = new Tretja.RodovniskiPes("ab", null, null);
        psi[68] = new Tretja.RodovniskiPes("ab", psi[67], psi[64]);
        psi[69] = new Tretja.RodovniskiPes("ab", psi[65], psi[68]);
        psi[70] = new Tretja.RodovniskiPes("ab", psi[66], psi[69]);
        psi[71] = new Tretja.RodovniskiPes("ab", null, null);
        psi[72] = new Tretja.RodovniskiPes("ab", psi[71], psi[70]);

        for (int i = 0;  i < psi.length;  i++) {
            System.out.printf("psi[%d] -> %b%n", i, psi[i].preveri());
        }
    }
}

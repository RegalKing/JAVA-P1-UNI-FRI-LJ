
import java.util.*;

public class Druga {

    public static int steviloShranjenih(int[] h, int[] w, int[] a, int[] b) {
        // popravite / dopolnite ...
        return -1;
    }
}

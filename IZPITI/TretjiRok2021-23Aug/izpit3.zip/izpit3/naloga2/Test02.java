
public class Test02 {

    public static void main(String[] args) {
        int[] h = {2, 5};
        int[] w = {3, 4, 2};
        int[] a = {1, 3, 1, 2, 4};
        int[] b = {6, 2, 4, 1, 4};
        System.out.println(Druga.steviloShranjenih(h, w, a, b));
    }
}

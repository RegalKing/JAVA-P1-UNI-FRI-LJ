
public class Test01 {

    public static void main(String[] args) {
        int[] h = {60, 50, 40, 80};
        int[] w = {70, 50, 60};
        int[] a = {50, 50, 50, 50, 50, 50, 50, 50, 50, 50};
        int[] b = {50, 50, 50, 50, 50, 50, 50, 50, 50, 50};
        System.out.println(Druga.steviloShranjenih(h, w, a, b));
    }
}


/*
 * tj.exe
 */

import java.util.*;

public class Cetrta {

    public static <T> List<T> odsek(Iterator<T> it, int p, int q) {
        // popravite / dopolnite ...
        return null;
    }

    public static Iterator<Integer> manjkajoci(Iterator<Integer> it, int zacetek) {
        // popravite / dopolnite ...
        return null;
    }

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po potrebi)
    }
}

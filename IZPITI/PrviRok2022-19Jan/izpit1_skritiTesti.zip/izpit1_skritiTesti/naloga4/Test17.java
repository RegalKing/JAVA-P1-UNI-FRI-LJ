
import java.util.*;

public class Test17 {

    public static void main(String[] args) {
        List<Integer> seznam = List.of(
            776, 520
        );
        System.out.println(Cetrta.odsek(seznam.iterator(), 0, 1));
    }
}

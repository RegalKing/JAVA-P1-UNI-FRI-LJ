
public class Test01 {

    public static void main(String[] args) {
        int m = 6;
        int[][] t = {{0, 2, 3}, {4, 1, 1}, {2, 4, 3}, {1, 5, 5}, {4, 3, 2}};
        System.out.println(Druga.najGlobina(m, t));
    }
}

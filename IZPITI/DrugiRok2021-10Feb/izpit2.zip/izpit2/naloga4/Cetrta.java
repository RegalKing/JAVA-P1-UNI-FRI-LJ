
/*
 * tj.exe
 */

import java.util.*;

public class Cetrta {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po potrebi)
    }

    public static <T> List<T> razmnozi(List<T> seznam, int n) {
        // popravite / dopolnite ...
        return null;
    }

    public static <T> Iterator<T> razmnozevalnik(List<T> seznam, int n) {
        // popravite / dopolnite ...
        return null;
    }
}

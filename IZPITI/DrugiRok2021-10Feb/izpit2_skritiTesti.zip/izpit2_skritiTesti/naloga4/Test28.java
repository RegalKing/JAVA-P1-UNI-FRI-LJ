
import java.util.*;

public class Test28 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(77);
        seznam.add(298);
        seznam.add(412);
        seznam.add(563);
        seznam.add(181);
        seznam.add(541);
        seznam.add(158);
        seznam.add(811);
        seznam.add(906);
        seznam.add(121);
        seznam.add(639);
        seznam.add(807);
        seznam.add(588);
        seznam.add(667);
        seznam.add(736);
        seznam.add(109);
        seznam.add(268);
        seznam.add(43);
        seznam.add(552);
        seznam.add(515);
        seznam.add(486);
        seznam.add(178);
        seznam.add(324);
        seznam.add(591);
        seznam.add(271);
        seznam.add(899);
        seznam.add(424);
        seznam.add(23);
        seznam.add(948);
        seznam.add(166);
        seznam.add(508);
        seznam.add(487);
        seznam.add(344);
        seznam.add(414);
        seznam.add(747);
        seznam.add(960);
        seznam.add(176);
        seznam.add(2);
        seznam.add(316);
        seznam.add(904);
        seznam.add(740);
        seznam.add(568);
        System.out.println(Cetrta.razmnozi(seznam, 7));
    }
}

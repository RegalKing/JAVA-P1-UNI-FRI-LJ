
import java.util.*;

public class Test10 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(619);
        seznam.add(939);
        seznam.add(497);
        seznam.add(637);
        seznam.add(126);
        seznam.add(150);
        System.out.println(Cetrta.razmnozi(seznam, 2));
    }
}


import java.util.*;

public class Test29 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("samorazelektrenje");
        seznam.add("valjalnica");
        seznam.add("interkongres");
        seznam.add("migriranje");
        seznam.add("adenoiden");
        seznam.add("kolajnar");
        seznam.add("rjavokremast");
        seznam.add("rondenjski");
        seznam.add("predmolierski");
        seznam.add("kontumacija");
        seznam.add("rastriranje");
        seznam.add("podkupljenec");
        seznam.add("kavalkata");
        seznam.add("raztezovalnica");
        seznam.add("argala");
        seznam.add("acetat");
        seznam.add("centilitrski");
        seznam.add("nematoden");
        seznam.add("pregljevski");
        seznam.add("obustaviti");
        seznam.add("proglica");
        seznam.add("artikulirati");
        seznam.add("korina");
        seznam.add("zlatkan");
        seznam.add("puhast");
        seznam.add("nadpodje");
        seznam.add("orgonski");
        seznam.add("seromlja");
        seznam.add("tetraplegija");
        seznam.add("modelka");
        seznam.add("landrarski");
        seznam.add("vmetavanje");
        seznam.add("socialistovski");
        seznam.add("kavalirka");
        seznam.add("prepraviti");
        seznam.add("pipercup");
        seznam.add("fasetiren");
        seznam.add("prilagodivost");
        seznam.add("neasimilativen");
        seznam.add("jerpergati");
        seznam.add("molavar");
        seznam.add("aktstudija");
        System.out.println(Cetrta.razmnozi(seznam, 8));
    }
}

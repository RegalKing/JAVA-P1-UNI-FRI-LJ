
import java.util.*;

public class Test26 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("dimetokson");
        seznam.add("neokrnjenost");
        seznam.add("nepremenljiv");
        seznam.add("prekvasovati");
        seznam.add("zakonoznanstvo");
        seznam.add("superporcija");
        seznam.add("ostolbeti");
        seznam.add("anastaza");
        seznam.add("bogvedi");
        seznam.add("onemagati");
        seznam.add("medlina");
        seznam.add("koleraba");
        seznam.add("zavest");
        seznam.add("medalelen");
        seznam.add("minorka");
        seznam.add("besjak");
        seznam.add("patriotski");
        seznam.add("interkvartil");
        seznam.add("pomoskovski");
        seznam.add("resorcinski");
        seznam.add("prednaobrazba");
        seznam.add("gozdomerec");
        seznam.add("tujost");
        seznam.add("fenilhidrazin");
        seznam.add("pastelnorjavkast");
        seznam.add("nagovati");
        seznam.add("hrumsniti");
        seznam.add("predkulturen");
        seznam.add("protagonistkin");
        seznam.add("brezspominski");
        seznam.add("parob");
        seznam.add("aglutinin");
        seznam.add("modropernat");
        seznam.add("kondicioniranost");
        seznam.add("streliti");
        seznam.add("tragos");
        seznam.add("nezamegljen");
        seznam.add("kravsa");
        seznam.add("debelogumen");
        seznam.add("semperjanski");
        seznam.add("numetalec");
        seznam.add("paleoendemit");
        System.out.println(Cetrta.razmnozi(seznam, 3));
    }
}

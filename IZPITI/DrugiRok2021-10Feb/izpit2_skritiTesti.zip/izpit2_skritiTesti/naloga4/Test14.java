
import java.util.*;

public class Test14 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("privetrina");
        seznam.add("tristodvajsetica");
        seznam.add("novorazvit");
        seznam.add("brejica");
        seznam.add("komatozen");
        seznam.add("bluzast");
        seznam.add("pljunkati");
        seznam.add("ultralokalen");
        seznam.add("ergometrin");
        seznam.add("dolgogorski");
        seznam.add("zategovalen");
        seznam.add("klorist");
        System.out.println(Cetrta.razmnozi(seznam, 3));
    }
}


import java.util.*;

public class Test01 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        System.out.println(Cetrta.razmnozi(seznam, 5));
    }
}


import java.util.*;

public class Test19 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(522);
        seznam.add(152);
        seznam.add(455);
        seznam.add(187);
        seznam.add(799);
        seznam.add(701);
        seznam.add(349);
        seznam.add(315);
        seznam.add(613);
        seznam.add(617);
        seznam.add(404);
        seznam.add(617);
        System.out.println(Cetrta.razmnozi(seznam, 9));
    }
}

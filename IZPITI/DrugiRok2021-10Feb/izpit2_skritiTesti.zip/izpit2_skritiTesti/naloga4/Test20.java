
import java.util.*;

public class Test20 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("radosumnost");
        seznam.add("majerjev");
        seznam.add("drugoovaden");
        seznam.add("jabka");
        seznam.add("coupe");
        seznam.add("mnogomiseln");
        seznam.add("dopisje");
        seznam.add("boksarka");
        seznam.add("steinheimski");
        seznam.add("vintgar");
        seznam.add("mizantropno");
        seznam.add("fotokarton");
        System.out.println(Cetrta.razmnozi(seznam, 11));
    }
}

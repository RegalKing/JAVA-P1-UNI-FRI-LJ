
import java.util.*;

public class Test02 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("vrstiti");
        System.out.println(Cetrta.razmnozi(seznam, 3));
    }
}

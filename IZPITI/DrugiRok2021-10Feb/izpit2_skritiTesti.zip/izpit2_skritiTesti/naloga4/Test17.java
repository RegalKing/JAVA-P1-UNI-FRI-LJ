
import java.util.*;

public class Test17 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("nakladovalec");
        seznam.add("skokec");
        seznam.add("mamalen");
        seznam.add("obraslek");
        seznam.add("preurejanje");
        seznam.add("latovec");
        seznam.add("interkolumnij");
        seznam.add("baziran");
        seznam.add("altruitek");
        seznam.add("majorat");
        seznam.add("enakomerje");
        seznam.add("dumdumski");
        System.out.println(Cetrta.razmnozi(seznam, 6));
    }
}


import java.util.*;

public class Test11 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("nezgodeno");
        seznam.add("izomika");
        seznam.add("silikaten");
        seznam.add("zdrsnjen");
        seznam.add("vzemati");
        seznam.add("groht");
        seznam.add("mitologiziranje");
        System.out.println(Cetrta.razmnozi(seznam, 4));
    }
}

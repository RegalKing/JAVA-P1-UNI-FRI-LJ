
import java.util.*;

public class Test05 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("identnosten");
        seznam.add("koreliranost");
        System.out.println(Cetrta.razmnozi(seznam, 7));
    }
}

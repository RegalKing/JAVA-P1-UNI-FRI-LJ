
import java.util.*;

public class Test23 {

    public static void main(String[] args) {
        List<String> seznam = new ArrayList<>();
        seznam.add("neprisodnost");
        seznam.add("avtorialen");
        seznam.add("preudarek");
        seznam.add("lepanje");
        seznam.add("ustnohigienski");
        seznam.add("volnatobrazden");
        seznam.add("imobilaren");
        seznam.add("nosec");
        seznam.add("tubelija");
        seznam.add("tisti");
        seznam.add("bioelektromagneten");
        seznam.add("kolaborantski");
        seznam.add("transglutealen");
        seznam.add("bebljaje");
        seznam.add("barhan");
        seznam.add("betoner");
        seznam.add("tvar");
        seznam.add("makrozbirnik");
        seznam.add("pinata");
        seznam.add("pogozdenost");
        System.out.println(Cetrta.razmnozi(seznam, 7));
    }
}

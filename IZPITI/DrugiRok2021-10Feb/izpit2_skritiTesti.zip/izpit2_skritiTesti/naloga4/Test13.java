
import java.util.*;

public class Test13 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(296);
        seznam.add(675);
        seznam.add(426);
        seznam.add(777);
        seznam.add(828);
        seznam.add(45);
        seznam.add(727);
        seznam.add(921);
        seznam.add(477);
        seznam.add(660);
        seznam.add(742);
        seznam.add(954);
        System.out.println(Cetrta.razmnozi(seznam, 2));
    }
}

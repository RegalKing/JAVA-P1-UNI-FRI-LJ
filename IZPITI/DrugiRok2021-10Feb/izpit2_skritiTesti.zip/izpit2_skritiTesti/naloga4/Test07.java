
import java.util.*;

public class Test07 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(348);
        seznam.add(405);
        seznam.add(46);
        System.out.println(Cetrta.razmnozi(seznam, 2));
    }
}

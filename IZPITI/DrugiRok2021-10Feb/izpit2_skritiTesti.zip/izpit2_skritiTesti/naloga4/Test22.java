
import java.util.*;

public class Test22 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(870);
        seznam.add(393);
        seznam.add(54);
        seznam.add(990);
        seznam.add(926);
        seznam.add(659);
        seznam.add(363);
        seznam.add(49);
        seznam.add(265);
        seznam.add(298);
        seznam.add(22);
        seznam.add(505);
        System.out.println(Cetrta.razmnozi(seznam, 15));
    }
}

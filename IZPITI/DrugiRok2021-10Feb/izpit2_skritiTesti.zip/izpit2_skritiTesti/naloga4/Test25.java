
import java.util.*;

public class Test25 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(984);
        seznam.add(762);
        seznam.add(741);
        seznam.add(694);
        seznam.add(952);
        seznam.add(197);
        seznam.add(926);
        seznam.add(423);
        seznam.add(119);
        seznam.add(786);
        seznam.add(732);
        seznam.add(998);
        seznam.add(97);
        seznam.add(960);
        seznam.add(945);
        seznam.add(265);
        seznam.add(852);
        seznam.add(359);
        seznam.add(299);
        seznam.add(824);
        seznam.add(749);
        seznam.add(435);
        System.out.println(Cetrta.razmnozi(seznam, 7));
    }
}

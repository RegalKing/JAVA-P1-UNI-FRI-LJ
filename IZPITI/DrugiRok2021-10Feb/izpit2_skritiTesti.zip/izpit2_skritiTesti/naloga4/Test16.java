
import java.util.*;

public class Test16 {

    public static void main(String[] args) {
        List<Integer> seznam = new ArrayList<>();
        seznam.add(589);
        seznam.add(67);
        seznam.add(303);
        seznam.add(494);
        seznam.add(689);
        seznam.add(787);
        seznam.add(699);
        seznam.add(960);
        seznam.add(486);
        seznam.add(703);
        seznam.add(682);
        seznam.add(661);
        System.out.println(Cetrta.razmnozi(seznam, 5));
    }
}

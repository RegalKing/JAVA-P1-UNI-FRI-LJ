
public class Test04 {

    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(3);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(4);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

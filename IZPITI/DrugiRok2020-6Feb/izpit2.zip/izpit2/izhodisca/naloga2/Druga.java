
/*
 * Testiranje:
 *
 * tj.exe
 */

import java.util.*;

public class Druga {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }

    //=========================================================================
    // V vseh testnih primerih velja:
    // 1 <= "stevilo vrstic tabele <= 100
    // 1 <= "stevilo stolpcev tabele <= 100
    //=========================================================================

    public static int zadnjaVrsticaZLocilom(char[][] krizanka) {
        // popravite / dopolnite ...
        return -9999;
    }

    //=========================================================================
    // V vseh testnih primerih velja:
    // 1 <= "stevilo vrstic tabele <= 100
    // 1 <= "stevilo stolpcev tabele <= 100
    // 0 <= stolpec < "stevilo stolpcev
    //=========================================================================

    public static char[] ktaBeseda(char[][] krizanka, int stolpec, int k) {
        // popravite / dopolnite ...
        return null;
    }
}


/*
 * Testiranje:
 *
 * tj.exe Cetrta.java . .
 */

import java.util.*;

public class Cetrta {

    public static void main(String[] args) {
        // dopolnite ...
    }

    // po potrebi dopolnite ...
}

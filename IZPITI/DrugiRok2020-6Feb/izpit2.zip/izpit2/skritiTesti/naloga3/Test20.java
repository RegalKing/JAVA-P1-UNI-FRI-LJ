
public class Test20 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(147);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(319);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

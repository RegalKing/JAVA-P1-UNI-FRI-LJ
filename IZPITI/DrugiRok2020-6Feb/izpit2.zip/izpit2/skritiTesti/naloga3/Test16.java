
public class Test16 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(350);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(830);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

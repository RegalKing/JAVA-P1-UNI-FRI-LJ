
public class Test22 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(750);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(906);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}


public class Test24 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(30);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(649);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}


public class Test19 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(896);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(380);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

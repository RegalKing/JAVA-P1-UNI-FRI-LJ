
public class Test18 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(206);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(599);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

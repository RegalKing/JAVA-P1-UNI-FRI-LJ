
public class Test15 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(31);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(152);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

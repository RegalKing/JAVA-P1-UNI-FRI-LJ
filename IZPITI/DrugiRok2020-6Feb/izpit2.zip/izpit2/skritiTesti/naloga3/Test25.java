
public class Test25 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(770);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(126);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

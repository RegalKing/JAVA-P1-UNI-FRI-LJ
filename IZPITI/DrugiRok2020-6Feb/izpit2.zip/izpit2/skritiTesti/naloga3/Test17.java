
public class Test17 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(384);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(279);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

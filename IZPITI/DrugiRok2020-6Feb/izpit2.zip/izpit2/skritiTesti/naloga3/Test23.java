
public class Test23 {
    public static void main(String[] args) {
        Tretja.Ukaz postavi = new Tretja.Postavi(286);
        Tretja.Ukaz odvzemi = new Tretja.Odvzemi(597);

        System.out.println(postavi);
        System.out.println(odvzemi);
    }
}

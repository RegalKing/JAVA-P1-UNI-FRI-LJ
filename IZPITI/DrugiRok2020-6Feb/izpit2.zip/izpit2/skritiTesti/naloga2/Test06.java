
public class Test06 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'y', 'i', 'p', 'b', '-', 'j', 'v', 'z', 'n', 'x', 'u', '-', 'u', 't'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'i', 'u', 'k', '-', 'c', 'w', 'f', 'c', 'b', 'n', 'k', 'f', 'g', 'y'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'q', 'k', 'h', 'z', 'r', 'g', 'o', 'b', 'b', 'b', 'p', 'f', 'q', 'h'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'y', 'i', 'q', 'a', 'q', 'u', 'y', 'f', 'z', 'h', 'f', 'o', 'h', 'l'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'j', 'v', 'g', 'n', 'a', 't', 'o', 'p', 'g', 'j', 'p', 'j', 'v', 'h'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}


public class Test17 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'b', 'l', 'z', 'f', 'u', 'i', 't', 'n', 'i', 'k', '-', '-', 'h', 'x', 'k', 'o'},
            {'g', 'e', 'l', 'c', 'o', 'd', '-', 'u', 'g', 'u', '-', 'z', 'x', 'n', 'y', 'f'},
            {'k', 'm', 'b', 'u', 't', 'o', 'b', 'y', 'c', 'e', 'e', 'r', 'v', 'f', 't', 'k'},
            {'b', 'u', 'y', 'u', 'r', 'e', '-', 'f', '-', 'f', 'b', 'z', '-', 'c', 'k', 'c'},
            {'j', 'u', 'k', 'o', 'x', 'z', 'd', 'q', 'c', 'd', 'l', 'z', 'u', 'm', 'z', 'l'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'h', 'q', 'd', 'r', 'u', 'j', 'r', 'k', 's', 'n', 'k', 'e', 'k', 'v', 'e', 'z'},
            {'g', 'y', 'i', 'g', 's', 'y', 'x', 'c', 'c', 'k', 'd', 'g', 'f', 'n', 'c', 'o'},
            {'x', 'u', 'k', 'y', 'p', 's', 'y', 'm', 'a', 'r', 'n', 'k', 'l', 'k', 'v', 'r'},
            {'j', 'o', 'v', 'y', 'o', 's', 'a', 'm', 'c', 'v', 'k', 's', 'u', 'c', 'p', 'v'},
            {'x', 'k', 'u', 'i', 'q', 'm', 'h', 'y', 'b', 'y', 't', 'a', 'm', 'm', 'c', 'u'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'f', 'r', 'e', 'j', 'c', 'a', 'r', '-', 'd', 'l', 'k', 'a', 'x', 'k', 'p', 's'},
            {'z', 'u', 'w', 'v', 'a', 'g', 'n', 'c', 'q', 'x', 'g', 'j', 'm', 'y', 'p', 'v'},
            {'c', 'o', 'w', 'r', 'h', 'h', 'h', 'm', 'r', 'r', 'v', 'y', 'f', 'a', 'r', 'i'},
            {'c', 'b', 'e', 'x', 'k', 'q', 'c', 'h', 'z', 'z', 'c', 'h', 'y', 'r', 'q', 'z'},
            {'v', 'v', 'p', 'v', 'p', 'b', 'l', 'm', 'e', 'u', 'n', 'n', 'e', 'b', 'e', 'k'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'n', 'z', 'p', 'c', 'a', 'z', 'n', 'z', 'b', 'v', '-', 'm', 'k', 'u', 'g', 'a'},
            {'e', 's', 'v', 't', 'l', 'o', 'g', 'y', 'b', 'l', 'x', 'd', 'h', 't', 'm', 'e'},
            {'v', 'f', 'u', 'n', 'u', 'o', 'n', 'k', 'h', 'p', 'p', 'g', 'p', 'l', 'h', 'w'},
            {'m', 'g', 'w', 'z', 'r', 'a', 'u', 'x', 'c', 'x', 'g', 'p', 's', 'n', 's', 'p'},
            {'c', 'c', 'k', 'e', 'x', 't', 'p', 'd', 'g', 'o', 'x', 'b', 'n', 'k', 'd', 'p'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'x', 'x', '-', 'd', 'o', 's', 'm', 'n', 'm', 'e', 'v', 'e', 'j', 'i', 'b', 'h'},
            {'k', 'z', 'c', 'b', 'f', 'o', 'p', 'a', 'f', 'i', 'v', 'm', 'y', 'n', 's', 'e'},
            {'-', 'q', 'u', 'i', 'w', 'h', 'w', 'f', 'g', 'm', 'e', 'x', 'z', '-', 'u', '-'},
            {'w', 'j', 'v', 'c', 's', 'c', 'a', 'z', 'm', 'r', 'm', 't', 'h', '-', 'q', 'd'},
            {'p', 'f', 'o', 'f', 'r', 'w', 'g', 'u', 'm', 'b', 'k', 'p', 'm', 't', 'b', 'e'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}


public class Test14 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'a'},
            {'v'},
            {'-'},
            {'-'},
            {'n'},
            {'k'},
            {'r'},
            {'b'},
            {'g'},
            {'-'},
            {'-'},
            {'-'},
            {'-'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'-'},
            {'-'},
            {'-'},
            {'i'},
            {'-'},
            {'-'},
            {'-'},
            {'-'},
            {'-'},
            {'d'},
            {'l'},
            {'l'},
            {'l'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'-'},
            {'-'},
            {'-'},
            {'-'},
            {'n'},
            {'-'},
            {'-'},
            {'-'},
            {'l'},
            {'-'},
            {'m'},
            {'n'},
            {'m'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'-'},
            {'-'},
            {'-'},
            {'-'},
            {'k'},
            {'s'},
            {'b'},
            {'g'},
            {'f'},
            {'n'},
            {'e'},
            {'v'},
            {'k'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'q'},
            {'l'},
            {'-'},
            {'i'},
            {'x'},
            {'i'},
            {'-'},
            {'x'},
            {'f'},
            {'e'},
            {'r'},
            {'h'},
            {'x'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

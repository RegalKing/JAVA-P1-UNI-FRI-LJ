
public class Test03 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'h', 'u', '-', '-', 'i'},
            {'-', 'o', 'z', 'n', 'l'},
            {'o', 'e', 'c', 'i', 'f'},
            {'n', '-', 'd', 'z', 'l'},
            {'s', 'e', 'i', 'k', 'n'},
            {'r', 'q', 'u', 'g', 'a'},
            {'d', 'i', 'd', '-', 'y'},
            {'-', 'p', '-', 'k', '-'},
            {'u', 't', 'a', 'g', 'a'},
            {'o', 'e', 'i', 'y', '-'},
            {'t', 'p', 'c', 'm', 'b'},
            {'i', 'j', 't', 'i', 'r'},
            {'e', 'v', 'u', 'u', '-'},
            {'u', '-', 'c', 'g', 'c'},
            {'-', 'j', 'n', 'y', 'n'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'i', 'd', '-', 'j', 'r'},
            {'k', 'p', 'w', 'o', 'p'},
            {'z', 'w', 'a', 'h', 'p'},
            {'o', 'e', 's', 'b', 'x'},
            {'d', 'b', 'e', 'j', 'z'},
            {'q', 'l', 'n', 's', 's'},
            {'v', 'x', 'j', 'k', 'l'},
            {'e', 't', 'b', 'c', 's'},
            {'d', 'i', 'd', 'w', 'f'},
            {'w', 'm', 'i', 'y', 'j'},
            {'w', 's', 'f', 'w', 'a'},
            {'g', 'q', 'q', 'y', 'f'},
            {'x', 'd', 's', 'c', 'b'},
            {'r', 'm', 'z', 'v', 'v'},
            {'i', 'y', 'j', 'j', 'o'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'-', '-', 'p', 'z', 'r'},
            {'q', 'd', 'c', 'q', '-'},
            {'z', '-', 'q', 'c', 'u'},
            {'o', 'i', 'p', 'k', 'k'},
            {'j', 's', 'i', 'v', 'n'},
            {'t', 'u', '-', 'x', 'h'},
            {'q', 'w', 'w', 'r', 'q'},
            {'r', 'j', 'y', 'l', 'w'},
            {'z', 'i', 'f', 'f', 'e'},
            {'t', 'a', 'p', 'k', 't'},
            {'w', 't', 'x', 'h', 'u'},
            {'p', 'n', 'e', 'l', 'd'},
            {'u', 'i', 'd', 'c', 'q'},
            {'m', 's', 'm', 'k', 'r'},
            {'v', 'y', 'j', 'h', 'r'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'w', 'o', 'q', 'i', 'o'},
            {'x', 'n', 'd', 's', 'j'},
            {'d', 'v', 'q', 'd', 'i'},
            {'k', '-', 'a', 't', 'd'},
            {'-', '-', 'h', '-', 'g'},
            {'-', 'o', 'w', 'c', '-'},
            {'-', '-', 'h', 'z', '-'},
            {'z', 'n', 'z', 'u', 'd'},
            {'k', '-', 'a', 'b', 'f'},
            {'m', 'z', '-', 'v', 'h'},
            {'e', 'r', '-', '-', 's'},
            {'r', 'j', 'j', 'x', 'a'},
            {'o', 'z', 'b', 'm', 'f'},
            {'t', 'q', 'z', 'l', 'z'},
            {'r', 'j', 'l', 'b', 'k'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'b', 'w', 'v', '-', 'm'},
            {'p', 'j', 'k', 'g', 'm'},
            {'t', 'v', 'z', 'v', 'v'},
            {'y', '-', 'o', 'n', 'l'},
            {'f', 'p', 'l', 'v', 'p'},
            {'f', 'l', 'o', 'v', 'd'},
            {'i', 'z', 'k', 'q', 'd'},
            {'y', 't', 't', 'q', 'g'},
            {'b', 'a', 'h', 'z', 'y'},
            {'x', 'o', 'y', 'o', 'x'},
            {'c', 't', 't', 'c', 'n'},
            {'q', 'y', 'm', 'j', 'i'},
            {'m', 'n', 'v', 'q', 'g'},
            {'n', 'o', 'q', 'f', 'l'},
            {'r', 'h', 'r', 'l', 'y'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

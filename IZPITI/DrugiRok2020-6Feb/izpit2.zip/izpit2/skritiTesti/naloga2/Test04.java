
public class Test04 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'x', 't', 'b', 'o', 'y', 'd', 't', 'j', 'f', 'x', 'e', 'o', 'z', 'p', 'r', 'm', 'h'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'w', 'e', 'n', 'l', 'v', 'o', 'i', 't', 'd', 'd', 'd', 'e', 'q', 'h', 'v', 'd', 'a'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'v', 'y', 'h', 'n', 'x', 'l', 'n', 'p', 'm', 'm', 'e', '-', 'b', 'm', 'y', 'p', 'b'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'j', 'j', 'c', 'z', 'w', '-', 'i', 'i', 'k', 'e', 'b', 'h', 'l', 'k', '-', 'f', 'p'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'g', 'k', '-', 'r', 'a', 'i', 'g', 'c', '-', 'l', 'q', 'b', 'm', 't', 'y', 'x', 'z'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

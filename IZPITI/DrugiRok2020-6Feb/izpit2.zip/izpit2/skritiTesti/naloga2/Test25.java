
public class Test25 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'h', 'a', 'n', 'b', 'a', 'x'},
            {'-', 'x', 'u', 'h', 'o', 'c'},
            {'p', 'b', 't', 'u', 'o', 'o'},
            {'z', 'e', 'e', 'o', 'u', 'p'},
            {'v', 'n', 'u', 'm', 'r', 'x'},
            {'p', 'g', 'q', 'a', 'c', 'k'},
            {'r', 'f', 'e', 'f', 'b', 't'},
            {'u', 'k', 'z', 'v', 'w', 'w'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'a', '-', 'a', 'u', 'd', 'c'},
            {'k', '-', 'r', 'm', 'z', 'r'},
            {'n', 'k', 'd', 'b', '-', 'f'},
            {'y', 'g', 'q', 'x', 'e', 'r'},
            {'i', 'n', 'b', 'q', 'r', 'n'},
            {'v', 'p', 'h', 'g', 'z', 'v'},
            {'i', 'o', 'f', 'z', 'j', 'n'},
            {'d', 'h', 'y', 'a', 'k', 'i'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'r', 'k', 'i', 'k', '-', 's'},
            {'m', '-', 'g', 'u', 'x', 'x'},
            {'c', 'a', 'y', 'm', 'x', 'w'},
            {'s', 'l', 's', 'u', 'n', 'p'},
            {'s', 'q', 'b', 'm', 'z', 's'},
            {'a', 'y', 'd', 'z', 'h', 'o'},
            {'w', 'g', 's', 'h', 'c', 'y'},
            {'x', 'u', 'e', 'w', 'w', 't'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'v', '-', 'w', 'v', 'l', 'g'},
            {'l', 'h', 'q', 'b', 'r', '-'},
            {'c', 'y', 'f', 'y', 'l', 'w'},
            {'y', '-', 'p', 'a', 'r', 'q'},
            {'d', 'f', '-', 'o', 'f', 'l'},
            {'f', 's', 'r', 'i', 'k', 'g'},
            {'y', 'c', 'e', 'g', 'l', 'd'},
            {'w', 'l', 'j', 'v', 'k', 'j'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'w', 'e', 'o', 'f', 'o', 'h'},
            {'a', 'e', 'i', 'v', 'g', '-'},
            {'y', '-', '-', '-', 'y', 'a'},
            {'i', '-', 'n', 'a', 'c', 'w'},
            {'c', 'b', 'h', 'f', 'a', 'd'},
            {'y', 'n', 'y', 'x', 't', 'a'},
            {'b', 'j', 'n', 'h', 'q', 'w'},
            {'p', 'i', 'h', 'i', 'q', 't'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

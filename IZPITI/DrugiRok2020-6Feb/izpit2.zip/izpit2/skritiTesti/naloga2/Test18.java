
public class Test18 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'z', 'w', '-', 'b'},
            {'-', '-', 'c', 'z'},
            {'y', 'v', 'z', 'h'},
            {'a', 'p', 'f', '-'},
            {'z', 'w', 'd', 'x'},
            {'l', 'j', 'c', 'y'},
            {'r', 'b', 'o', 'd'},
            {'r', 't', 'z', 'h'},
            {'n', 'c', 'h', 'w'},
            {'z', 'w', 'a', 'b'},
            {'o', 'f', 'w', 'q'},
            {'k', 't', 'a', 'z'},
            {'o', 'c', 'v', 'c'},
            {'g', 'f', 'o', 'n'},
            {'b', 'v', 'u', 'd'},
            {'m', 'i', 'q', 'e'},
            {'s', 's', 'j', 'm'},
            {'h', 'd', 'k', 'a'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'-', 's', 't', 'e'},
            {'e', 's', 'd', 'x'},
            {'-', 'n', 'n', 'f'},
            {'a', 'd', 'u', 'j'},
            {'-', 'r', 'g', '-'},
            {'-', 'd', '-', 'x'},
            {'-', 'i', 'i', 'e'},
            {'w', 'y', 'f', 'd'},
            {'-', 'x', 'n', 'd'},
            {'r', '-', 'v', '-'},
            {'z', 'v', 'l', 'd'},
            {'g', '-', 'w', '-'},
            {'-', 'i', 'q', '-'},
            {'f', '-', 'y', 'n'},
            {'g', 't', 'x', '-'},
            {'r', 'u', 'x', '-'},
            {'-', 'r', 'e', 'z'},
            {'y', '-', 'u', 'o'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'-', 'p', 'u', 't'},
            {'d', 'a', 'b', '-'},
            {'d', '-', 'e', 'e'},
            {'l', 'u', 'w', 'f'},
            {'b', 'q', 'y', 'c'},
            {'-', 'p', 'f', 'o'},
            {'f', 'l', 'm', 'u'},
            {'-', '-', '-', 'v'},
            {'-', 's', '-', 'q'},
            {'-', '-', 'f', '-'},
            {'y', '-', '-', 'i'},
            {'u', 'd', 'n', 'j'},
            {'q', 'x', 'j', 'e'},
            {'t', 'q', 'h', 'v'},
            {'x', 'v', 'j', 'b'},
            {'h', 'j', 'e', 'n'},
            {'p', 'j', 'h', 'u'},
            {'p', 'w', 'y', 'm'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'o', 'r', 'd', 'k'},
            {'-', '-', 'x', 'n'},
            {'x', 't', 'x', 'y'},
            {'d', 'd', 'w', 'f'},
            {'g', 'y', 'g', 'd'},
            {'l', 'h', 'o', 'r'},
            {'o', 'n', 'b', 'b'},
            {'p', 'e', 'm', 'k'},
            {'p', 's', 'k', 'e'},
            {'a', 's', 'v', 'm'},
            {'t', 'l', 'v', 'h'},
            {'g', 'd', 'z', 'z'},
            {'v', 'y', 'l', 'a'},
            {'r', 'f', 'f', 'u'},
            {'h', 't', 'u', 'w'},
            {'t', 'n', 'f', 'u'},
            {'r', 'z', 'g', 'r'},
            {'u', 'o', 'b', 'o'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'q', 'u', 'd', 'h'},
            {'f', 'h', 's', '-'},
            {'a', '-', 'n', 't'},
            {'m', 'u', 's', 'g'},
            {'r', 'l', 'd', 'e'},
            {'m', 'w', 'j', 'h'},
            {'y', '-', 'i', 'n'},
            {'-', '-', 'j', 'z'},
            {'d', 'm', 'a', 'm'},
            {'-', '-', 'v', '-'},
            {'j', 'f', 'z', '-'},
            {'-', '-', 'h', '-'},
            {'t', 'j', 'u', 'x'},
            {'r', 'g', 'y', 'c'},
            {'o', 'd', 't', 'n'},
            {'c', 'e', 'v', 'w'},
            {'g', 'q', 'j', 'j'},
            {'v', 'x', 'z', 'e'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

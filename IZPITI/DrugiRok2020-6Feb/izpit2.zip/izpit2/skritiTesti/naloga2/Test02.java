
public class Test02 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'h', 'z', 'v', '-', 'n'},
            {'-', '-', 'f', 'd', 'k'},
            {'h', 'i', '-', 'r', 'g'},
            {'g', 't', 'i', 'n', 'k'},
            {'b', 'k', 'n', 'c', 'h'},
            {'u', 'o', 'b', 's', 'r'},
            {'s', 'p', 'r', 'z', 'w'},
            {'h', 'r', 'n', 'z', 'o'},
            {'r', 'v', 'n', 't', 's'},
            {'l', 'v', 'r', 'x', 'g'},
            {'c', 'k', 'n', 'i', 'p'},
            {'y', 'o', 'k', 'y', 't'},
            {'s', 'i', 'y', 'c', 'v'},
            {'d', 'm', 'u', 'o', 'k'},
            {'t', 'm', 'b', 'v', 'w'},
            {'l', 'e', 'r', 'h', 'a'},
            {'o', 's', 'm', 'm', 'c'},
            {'p', 'i', 'a', 'q', 'r'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'f', '-', 'd', 's', 'y'},
            {'p', '-', 'z', 'q', 'm'},
            {'i', 'q', 's', 'q', 'i'},
            {'l', 'w', 'r', 'o', 'u'},
            {'a', 'm', 'k', '-', 'n'},
            {'d', 't', 'u', 'y', 'y'},
            {'d', 'k', 'v', 'j', 'c'},
            {'y', 'm', 'o', '-', 'x'},
            {'y', 'u', '-', 'z', 'q'},
            {'j', 's', '-', 'h', 's'},
            {'v', '-', 'y', 'n', 't'},
            {'h', 'q', '-', 'a', 'e'},
            {'i', 'g', '-', 'r', 'b'},
            {'u', '-', 'b', 'd', 'e'},
            {'l', 'b', '-', 'c', 'w'},
            {'h', 'e', 'l', 'r', 'x'},
            {'i', 'c', 't', 'p', 'b'},
            {'u', 'y', 'c', 't', 'h'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'f', 'i', 'p', 'u', 'r'},
            {'x', 't', 'z', 'h', 'l'},
            {'m', '-', '-', 'h', 't'},
            {'m', '-', 'f', '-', 'm'},
            {'f', '-', 'd', '-', 'k'},
            {'k', 't', 'e', 'z', 'h'},
            {'-', 'e', '-', 'c', 'u'},
            {'m', 'm', 'c', 'f', 'h'},
            {'t', 'a', '-', 'g', 'k'},
            {'m', 'd', 'o', 'k', 'u'},
            {'-', '-', 'u', 'w', '-'},
            {'z', 'j', '-', 'k', 'x'},
            {'w', '-', 'v', '-', 'q'},
            {'-', '-', 'y', 'l', 'q'},
            {'y', 'x', '-', 'c', 'h'},
            {'z', 'v', 'b', 'c', 'q'},
            {'v', 'z', 'p', 'b', 'o'},
            {'t', 'k', 'w', 'n', 'j'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'m', '-', '-', 'o', 'l'},
            {'e', 'z', 'h', 'b', 'p'},
            {'l', 't', 'u', 'j', 'n'},
            {'r', 'i', 'a', 'p', 'm'},
            {'r', 'i', 'n', 'n', 'q'},
            {'s', 'e', 'n', 'u', 'q'},
            {'p', 'u', 'x', 'y', 'm'},
            {'f', 's', 'b', 'p', 't'},
            {'j', 'u', 'y', 'n', 'w'},
            {'z', 'u', 'd', 'w', 't'},
            {'u', 'o', 'v', 'r', 'k'},
            {'q', 'd', 'l', 'h', 'f'},
            {'u', 'm', 'i', 'q', 'g'},
            {'x', 'r', 'p', 't', 'h'},
            {'c', 'd', 't', 'e', 'q'},
            {'l', 'k', 'p', 'o', 'b'},
            {'i', 't', 'm', 'f', 'n'},
            {'l', 'f', 's', 'q', 'o'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'-', 'n', 'j', '-', 's'},
            {'u', 'h', 'y', 'b', 't'},
            {'d', 'r', 'v', 'd', 'j'},
            {'d', 'g', 'c', '-', 'x'},
            {'k', 'x', 'j', 'x', 'z'},
            {'u', '-', '-', '-', 'c'},
            {'e', '-', 'a', '-', 'w'},
            {'-', 'e', 'z', 'u', 'e'},
            {'v', 'e', 'i', 'q', 'h'},
            {'y', 'h', 'y', 'u', 's'},
            {'u', 'c', 'h', 'q', 't'},
            {'c', 'g', 's', 'l', 'n'},
            {'n', 'v', '-', 'u', 's'},
            {'s', 'e', 'p', 'j', 'h'},
            {'v', 'k', 'f', 'l', 'g'},
            {'a', 'h', 'j', 'q', 'y'},
            {'m', 'd', 'o', 'p', 'v'},
            {'e', 'q', 's', 'z', 'r'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

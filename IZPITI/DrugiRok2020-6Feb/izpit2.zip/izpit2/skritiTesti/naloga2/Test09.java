
public class Test09 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'v', 'n', 'w', 'w', 'h', 'l', 'k', 'p', 'f', 'b', 'r', 'i', 'g', 'f', '-', 'c', 'p'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'u', 'k', 't', 'l', 'l', 'y', 's', 'y', 'c', 'g', 'f', 'j', 'a', 'j', 'o', 'o', 'q'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'x', 'y', 'w', 'f', 'a', 'h', 'x', 'e', 'y', 's', 'p', 't', 'k', 'j', 'd', 'l', 's'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'z', 't', 'l', 'q', 'p', 'g', 'g', 't', 'y', 'e', 't', 'e', 'e', 'g', 'b', 'c', 'f'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'d', 'm', 'l', 'i', 'v', 'q', 'e', 'k', 'a', 'p', 't', '-', 'u', 'e', 'n', 'y', 'r'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}


public class Test20 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'d', 'w', 'h', '-', 'm', 'e'},
            {'h', 'w', '-', 't', 'u', 'n'},
            {'c', '-', 'h', 'm', 'q', 'c'},
            {'n', 'd', 'f', 'm', 't', 'g'},
            {'n', 'p', 'l', 'o', 'n', 'k'},
            {'q', 'q', 'i', 'x', 'j', 'c'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'i', 'k', 'i', 'r', 'o', 'a'},
            {'t', 'e', 'n', 's', 'p', 'a'},
            {'a', 'g', 'w', '-', 'q', 'w'},
            {'y', '-', 'k', 'g', 't', 'c'},
            {'k', 'z', 'x', 'b', 'a', 'u'},
            {'b', 'b', 'v', 'b', 'a', 'y'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'u', 'n', '-', 'p', 'p', 'n'},
            {'i', 'l', 'f', 'w', 'l', 'r'},
            {'a', 'o', 'q', 'q', 'z', 'm'},
            {'x', 'z', 'l', 'p', 'n', 'w'},
            {'s', 't', 'o', 's', 'x', 'l'},
            {'d', 'a', 'i', 'a', 'u', 'r'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'i', 'v', 'p', 'p', 'j', 'u'},
            {'w', 'i', 'j', 'd', 'j', 'x'},
            {'b', 'q', 'e', 'm', 'q', '-'},
            {'d', 'd', 'w', 'g', 'j', 's'},
            {'j', 'f', '-', 'z', 'c', 'o'},
            {'r', 'g', 'f', 'e', 'b', 'a'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'k', '-', 'q', 'q', 'b', 'u'},
            {'f', 'i', 'y', '-', 's', 'p'},
            {'r', '-', 'f', 'a', '-', 'x'},
            {'g', 'q', 'j', 's', 'r', 'm'},
            {'e', 'b', 'h', 'b', 'j', 't'},
            {'z', 'h', 'x', 'p', 'p', 'p'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}


public class Test16 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'i', 'l', 't', '-', '-', 'w', 'v', 'p', 'p', 'i', 'h', 'd', 'v', 'y', 'i', 'z', 'z', 'n', 'h', 'z'},
            {'f', 'v', 'd', 'r', 'q', 'l', 'h', 'm', 'u', 'p', 's', 'o', 'v', 'o', 'r', 'x', 'r', 'o', 'b', 'r'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'e', 'c', 'h', 'd', 't', 'x', 'p', 'a', 'l', 'r', 'k', 'd', 'f', 'p', 'h', 'i', 'l', 't', 'n', 'y'},
            {'o', 'o', 'z', 'g', 'x', 'f', 'm', 'g', 'm', 'c', 'a', 'x', 'm', 'z', 'r', 'g', 'j', 's', 'g', 's'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'g', 'u', 'e', 'b', 'j', '-', 's', 's', 'e', 'z', 'e', 'n', 'r', 'l', 'v', '-', 'f', 'w', 'z', '-'},
            {'g', 'v', 'i', 'p', 'c', 't', 'l', 's', 'p', 'n', 'd', 's', 'x', 'a', 'w', 'f', 'u', 'i', 'z', 'l'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'g', 'z', 'f', 'u', 'u', 'f', 'p', 'p', 'c', 'n', 'u', 'h', 'x', 'n', 'r', '-', 'a', 'f', 'o', 'e'},
            {'o', 'k', 'z', 'x', 'a', 'y', 'q', 's', 'e', 'u', 'k', 'k', 'f', 'n', 'j', 'g', 'a', 'a', 'i', 'i'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'k', '-', 'i', 'k', 'u', 'g', 'l', '-', 'o', 'm', 'b', 'b', 'l', '-', 's', 'f', 'y', 'l', 'f', 'r'},
            {'o', 'h', 'e', 'm', 'h', 'c', 'i', 'o', 'g', 'y', 'e', 'n', 'i', 'q', 'z', 'm', 'm', 'l', 'q', 'g'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

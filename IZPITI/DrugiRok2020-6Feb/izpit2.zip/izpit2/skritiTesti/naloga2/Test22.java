
public class Test22 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'r', 'd', 'u', 'j', 'o', 'd', 'b', '-', 'v', 'x', 'o', 'o'},
            {'d', 't', 'q', 'v', 'y', 's', 'g', 't', 'i', '-', 'g', 'z'},
            {'a', 's', 'z', 'w', 'w', 'v', 'j', 'm', 'a', 'p', 'a', 'v'},
            {'d', 's', 'r', 'p', '-', '-', 'r', 'k', 'j', 'w', 'f', 'w'},
            {'j', 'f', 'c', 'w', 'o', 'v', 'j', 'x', 'l', 'b', 'q', 'n'},
            {'q', 't', 'd', 'n', 'u', 'r', 'u', 't', 'u', 't', 'd', 'l'},
            {'s', 'i', 'y', 'p', 'v', 'j', 'j', 'l', 'w', 'n', 'y', 'h'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'g', 'n', 'a', 'n', 'k', 'j', 'g', 'y', 'c', 'y', '-', 'x'},
            {'c', 'i', 'q', 'a', 'k', 'n', 'f', 'c', 'v', 't', 'g', 's'},
            {'x', 'z', 'h', 'l', 'q', 't', 'q', 'i', 'c', 'z', 'c', 'g'},
            {'i', 'o', 'j', 'h', 'z', 'i', 'y', 'j', 'n', 'k', 'q', 'w'},
            {'n', 'n', 'a', 'm', 'i', 'y', 'h', 'm', 'r', 't', 'c', 'i'},
            {'n', 'i', 's', 'h', 't', 'p', 'h', 'm', 'v', 'h', 'i', 'z'},
            {'n', 'b', 'f', 'a', 'q', 'a', 'j', 'j', 'v', 'y', 'i', 'f'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'x', 'v', 'd', 'j', 'x', 'l', 'e', 'c', 'p', 'd', '-', 'q'},
            {'-', 't', 'b', 'n', 'j', 'd', 'y', 'o', 'z', 'x', 'a', 's'},
            {'a', 'v', '-', 'y', 'q', 'j', 'f', 'f', 'b', '-', 'h', 'g'},
            {'c', '-', 'f', 'b', 'z', 'q', '-', 'w', 'z', 'e', 'u', 'y'},
            {'w', 's', 'l', 'w', 'u', 'm', '-', 'd', 'b', 'c', 'j', 'j'},
            {'f', 'j', 'p', 'i', 'm', 'v', 'r', 'a', 'h', 'r', 'v', 'y'},
            {'p', 'c', 's', 'w', 'm', 'c', 'q', 'm', 'u', 'i', 'p', 'z'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'a', 'x', 'd', 'l', '-', 'm', 'y', 'z', 'c', 'z', 's', 'd'},
            {'x', 'v', '-', 'f', 'y', 'e', 's', 'f', 'e', '-', '-', 'd'},
            {'p', 'j', 'z', 'i', 'z', 't', 'z', 'f', 'h', 'p', 'm', 'p'},
            {'n', 'm', 'l', 'l', 'e', 't', 'u', 'g', 'u', 's', 'g', 'n'},
            {'o', 'z', 'm', 'x', 'h', 'n', 'o', 'm', 'j', 'k', 'm', 'g'},
            {'s', 'u', 'i', 'g', 'n', 'l', 'k', 'o', 'e', 'j', 'b', 'c'},
            {'i', 'o', 'w', 't', 'f', 'v', 'w', 'x', 'r', 'g', 'r', 'm'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'f', 'r', 'q', 'k', 'q', 'u', 'l', 'b', '-', 'd', 'w', 'k'},
            {'j', '-', 's', 'i', 'q', 'a', 'u', 'o', 'v', 'n', 't', 'o'},
            {'y', 'u', 'm', 'u', 'w', 'n', 'm', 'd', 't', 'u', 't', 'a'},
            {'e', 'j', 'l', 'n', 's', 'a', 'f', 't', 'h', 'f', 'a', 'e'},
            {'q', 'd', 'x', 'k', 't', 'l', 'n', 'e', 'm', 'n', 'n', 's'},
            {'q', 'w', 't', 'f', 'd', 'y', 's', 'a', 'g', 'y', 'a', 'm'},
            {'h', 'g', 'l', 'p', 'u', 'g', 'k', 'o', 'y', 'c', 'u', 'b'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

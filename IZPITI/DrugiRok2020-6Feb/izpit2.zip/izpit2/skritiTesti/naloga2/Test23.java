
public class Test23 {

    public static void main(String[] args) {
        char[][] krizanka0 = {
            {'p', 'n', 's', 'e', 'o', 'q', 'd', 'l', 'c', 'm', 't', 't', 'l', 's', 'k', 'j'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka0));

        char[][] krizanka1 = {
            {'k', 'f', 'h', 'w', '-', 'm', '-', 'o', '-', 'y', 'z', 'g', 'h', 'u', 'y', 'l'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka1));

        char[][] krizanka2 = {
            {'z', 'q', 'm', 'h', 'e', 'b', '-', 'e', 'f', 'i', 'y', 'o', 'b', 'x', 'r', 'j'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka2));

        char[][] krizanka3 = {
            {'v', 'k', 'k', 'f', 'w', '-', 'w', '-', 'n', 'l', 'e', 'g', 'b', 'f', 'w', 'j'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka3));

        char[][] krizanka4 = {
            {'x', 'j', 'k', 'g', 't', 'v', 'y', 'i', 't', 'p', 'i', 'l', 'b', 'p', 'b', 's'},
        };
        System.out.println(Druga.zadnjaVrsticaZLocilom(krizanka4));

    }
}

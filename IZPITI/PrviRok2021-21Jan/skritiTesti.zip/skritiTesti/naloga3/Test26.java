
public class Test26 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 99);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 136);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 469);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 229);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 367);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 43);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 159);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 88);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 321);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 295);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 271);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 324);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 476);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 208);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 14);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 245);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 3);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 500);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 241);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 165);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 263);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 373);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 437);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 477);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 215);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 207);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 382);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 62);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 348);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 356);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 106);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 355);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 367);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 203);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 23);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 402);
        Tretja.Opravilo o36 = new Tretja.Opravilo("o36", 158);
        Tretja.Opravilo o37 = new Tretja.Opravilo("o37", 27);
        Tretja.Opravilo o38 = new Tretja.Opravilo("o38", 90);
        Tretja.Opravilo o39 = new Tretja.Opravilo("o39", 124);
        Tretja.Opravilo o40 = new Tretja.Opravilo("o40", 331);
        Tretja.Opravilo o41 = new Tretja.Opravilo("o41", 370);
        Tretja.Opravilo o42 = new Tretja.Opravilo("o42", 441);
        Tretja.Opravilo o43 = new Tretja.Opravilo("o43", 25);
        Tretja.Opravilo o44 = new Tretja.Opravilo("o44", 321);
        Tretja.Opravilo o45 = new Tretja.Opravilo("o45", 470);
        Tretja.Opravilo o46 = new Tretja.Opravilo("o46", 332);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o1, o40, o5, o0, o12});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o7, o9});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o8, o39, o20, o18, o35, o11, o42, o19});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o0, o40, o23, o4, o11, o29});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o11, o24, o18});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o31, o29, o25});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o24, o43, o29, o40, o10, o8});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o46, o2, o21, o16, o1, o7, o27});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o46, o18});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o29, o35, o1, o36, o27, o13, o39, o26, o28});

        Tretja.Delavnica delavnica = new Tretja.Delavnica(new Tretja.Delavec[]{
            new Tretja.Delavec("Vinko Antolin", 296),
            new Tretja.Delavec("Romana Furlan", 829),
            new Tretja.Delavec("Ula Ivnik", 786),
            new Tretja.Delavec("Lara Oblak", 144),
            new Tretja.Delavec("Vesna Han", 785),
            new Tretja.Delavec("Ana Ivnik", 776),
            new Tretja.Delavec("Franci Klasinc", 908),
            new Tretja.Delavec("Simon Ivnik", 394),
            new Tretja.Delavec("Urban Jerman", 149),
            new Tretja.Delavec("Maja Ravnikar", 833),
            new Tretja.Delavec("Janez Ermenc", 506),
            new Tretja.Delavec("Leon Sovinc", 169),
            new Tretja.Delavec("Gregor Ravnikar", 666),
            new Tretja.Delavec("Zoran Antolin", 769),
            new Tretja.Delavec("Zinka Golob", 31),
            new Tretja.Delavec("Emil Vidic", 183),
            new Tretja.Delavec("Lara Mihevc", 795),
            new Tretja.Delavec("Vesna Antolin", 633),
            new Tretja.Delavec("Leon Oblak", 901),
            new Tretja.Delavec("Cvetka Han", 796),
            new Tretja.Delavec("Sonja Ravnikar", 948),
            new Tretja.Delavec("Francka Ermenc", 510),
            new Tretja.Delavec("Branka Golob", 259),
            new Tretja.Delavec("Karla Mihevc", 794),
            new Tretja.Delavec("Andrej Sovinc", 463),
            new Tretja.Delavec("Zoran Mihevc", 213),
            new Tretja.Delavec("Roman Vidic", 477),
            new Tretja.Delavec("Urban Urlep", 357),
            new Tretja.Delavec("Oton Novak", 154),
            new Tretja.Delavec("Gregor Tanko", 386),
            new Tretja.Delavec("Bojan Novak", 335),
        });

        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p4, p5, p0}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p6, p8}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3, p9}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p8, p1}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p9}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p2, p5, p7, p6, p4}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p9, p6, p2}));
    }
}

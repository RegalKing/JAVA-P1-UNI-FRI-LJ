
public class Test31 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 196);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 204);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 143);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 9);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 211);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 164);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 309);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 63);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 355);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 443);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 362);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 472);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 97);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 449);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 57);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 432);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 53);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 214);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 481);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 249);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 269);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 81);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 203);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 402);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 157);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 267);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 130);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 143);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 323);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 249);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 457);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 479);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 316);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 146);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 300);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 334);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o1, o10});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o23, o5, o0, o3, o4, o31});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o27, o20, o7, o33, o13, o34, o18});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o14, o8, o5, o23, o16});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o17});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o12, o5, o11, o0, o31, o19, o3});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o32, o10, o24});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o8, o13, o14, o30});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o28, o4});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o25, o34, o4, o8});
        Tretja.Projekt p10 = new Tretja.Projekt("p10", new Tretja.Opravilo[]{o29, o23, o6, o11});
        Tretja.Projekt p11 = new Tretja.Projekt("p11", new Tretja.Opravilo[]{o21, o29});
        Tretja.Projekt p12 = new Tretja.Projekt("p12", new Tretja.Opravilo[]{o29, o4, o28, o21, o33, o27, o20});
        Tretja.Projekt p13 = new Tretja.Projekt("p13", new Tretja.Opravilo[]{o31, o29, o9, o34, o18, o13, o25});

        Tretja.Delavnica delavnica = new Tretja.Delavnica(new Tretja.Delavec[]{
            new Tretja.Delavec("Dejan Novak", 255),
            new Tretja.Delavec("Vinko Cevc", 911),
            new Tretja.Delavec("Urban Klasinc", 587),
            new Tretja.Delavec("Gabrijela Bevk", 113),
            new Tretja.Delavec("Gabrijela Zorman", 114),
            new Tretja.Delavec("Janez Zorman", 386),
            new Tretja.Delavec("Maja Pirc", 638),
            new Tretja.Delavec("Cene Lipnik", 31),
            new Tretja.Delavec("Leon Debeljak", 794),
            new Tretja.Delavec("Branka Lipnik", 746),
            new Tretja.Delavec("Janez Lipnik", 444),
            new Tretja.Delavec("Hinko Mihevc", 326),
            new Tretja.Delavec("Petra Bevk", 986),
            new Tretja.Delavec("Dejan Klasinc", 181),
            new Tretja.Delavec("Ana Mihevc", 646),
            new Tretja.Delavec("Francka Golob", 943),
            new Tretja.Delavec("Roman Ermenc", 927),
            new Tretja.Delavec("Leon Ivnik", 87),
            new Tretja.Delavec("Eva Debeljak", 758),
            new Tretja.Delavec("Ana Klasinc", 341),
            new Tretja.Delavec("Vesna Oblak", 208),
            new Tretja.Delavec("Maja Bevk", 706),
            new Tretja.Delavec("Emil Urlep", 229),
            new Tretja.Delavec("Karla Vidic", 121),
            new Tretja.Delavec("Tilen Tanko", 672),
            new Tretja.Delavec("Gregor Jerman", 810),
            new Tretja.Delavec("Maja Lipnik", 692),
            new Tretja.Delavec("Leon Oblak", 462),
            new Tretja.Delavec("Ula Mihevc", 740),
            new Tretja.Delavec("Olga Ermenc", 471),
            new Tretja.Delavec("Emil Jerman", 130),
            new Tretja.Delavec("Gregor Pirc", 642),
            new Tretja.Delavec("Leon Zorman", 637),
            new Tretja.Delavec("Ula Ermenc", 337),
            new Tretja.Delavec("Gregor Pirc", 736),
            new Tretja.Delavec("Cvetka Oblak", 271),
            new Tretja.Delavec("Zoran Han", 800),
            new Tretja.Delavec("Andrej Han", 970),
            new Tretja.Delavec("Hinko Tanko", 587),
            new Tretja.Delavec("Branka Debeljak", 731),
            new Tretja.Delavec("Cene Furlan", 412),
            new Tretja.Delavec("Simon Jerman", 497),
            new Tretja.Delavec("Tilen Zorman", 554),
            new Tretja.Delavec("Zoran Ravnikar", 400),
            new Tretja.Delavec("Franci Furlan", 876),
            new Tretja.Delavec("Lara Cevc", 11),
            new Tretja.Delavec("Emil Ermenc", 512),
            new Tretja.Delavec("Karla Furlan", 284),
            new Tretja.Delavec("Simon Antolin", 266),
            new Tretja.Delavec("Dejan Cevc", 132),
            new Tretja.Delavec("Petra Ravnikar", 505),
            new Tretja.Delavec("Lara Oblak", 84),
            new Tretja.Delavec("Eva Oblak", 777),
            new Tretja.Delavec("Tanja Lipnik", 811),
            new Tretja.Delavec("Branka Zorman", 552),
            new Tretja.Delavec("Zinka Novak", 561),
        });

        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p7, p3, p8, p5, p12, p0, p13}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p9, p6, p13, p11, p2}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p3, p12, p4}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p7, p9, p6, p3, p12, p8}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p6, p10, p7, p13, p4, p11, p5}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p10, p12, p13, p2, p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3, p8, p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p13, p0}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p12, p6}));
    }
}


public class Test09 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 957);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 277);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 80);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 218);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 488);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 786);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 124);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 692);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 439);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 531);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 130);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 959);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 291);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 584);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 369);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 360);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 499);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 268);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 463);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 982);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 337);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 299);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 672);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 771);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 813);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 508);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 270);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 459);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 355);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 897);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 580);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 717);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 214);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 910);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 472);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 191);
        Tretja.Opravilo o36 = new Tretja.Opravilo("o36", 11);
        Tretja.Opravilo o37 = new Tretja.Opravilo("o37", 352);
        Tretja.Opravilo o38 = new Tretja.Opravilo("o38", 437);
        Tretja.Opravilo o39 = new Tretja.Opravilo("o39", 894);
        Tretja.Opravilo o40 = new Tretja.Opravilo("o40", 23);
        Tretja.Opravilo o41 = new Tretja.Opravilo("o41", 181);
        Tretja.Opravilo o42 = new Tretja.Opravilo("o42", 808);
        Tretja.Opravilo o43 = new Tretja.Opravilo("o43", 735);
        Tretja.Opravilo o44 = new Tretja.Opravilo("o44", 930);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o2, o27, o18, o31, o28, o17, o40, o3, o34, o22, o4});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o17, o41, o9, o22});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o32, o44, o18, o9, o35, o43, o0, o6, o16});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o17, o32, o28, o8, o37});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o44, o13, o2, o22, o3, o20, o26, o32, o7, o28, o15, o0, o40, o29});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o8, o41, o29, o40, o32, o22, o4, o42, o20, o3});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o34, o20, o29, o21, o6, o2, o33, o0});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o21, o2, o12, o4, o34});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o35, o30, o29, o6, o21, o25, o8});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o6, o2, o33, o34, o30, o21, o40, o39, o31, o17, o4, o22, o24, o3, o38});
        Tretja.Projekt p10 = new Tretja.Projekt("p10", new Tretja.Opravilo[]{o5, o4, o24, o34, o11, o44, o2, o17});
        Tretja.Projekt p11 = new Tretja.Projekt("p11", new Tretja.Opravilo[]{o15, o37, o34, o30, o10, o40, o5, o7, o39});
        Tretja.Projekt p12 = new Tretja.Projekt("p12", new Tretja.Opravilo[]{o24, o13, o11, o26, o29, o43, o37, o20, o12, o40, o5});

        System.out.println(p0.zahtevnost());
        System.out.println(p1.zahtevnost());
        System.out.println(p2.zahtevnost());
        System.out.println(p3.zahtevnost());
        System.out.println(p4.zahtevnost());
        System.out.println(p5.zahtevnost());
        System.out.println(p6.zahtevnost());
        System.out.println(p7.zahtevnost());
        System.out.println(p8.zahtevnost());
        System.out.println(p9.zahtevnost());
        System.out.println(p10.zahtevnost());
        System.out.println(p11.zahtevnost());
        System.out.println(p12.zahtevnost());
    }
}

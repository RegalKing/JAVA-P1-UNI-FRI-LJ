
public class Test19 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 357);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 292);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 492);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 419);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 201);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 324);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 63);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 12);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 116);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 480);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 106);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 4);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 367);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 48);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 361);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 141);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 405);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 208);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 365);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 477);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 308);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 399);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 370);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 500);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 57);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 153);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 277);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 96);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 142);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 367);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o17, o14});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o29, o9});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o5, o15, o19});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o12, o29, o9, o0});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o29, o19});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o17, o18});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o9, o11, o26, o7});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o19, o25, o12, o24, o26});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o27, o4});

        Tretja.Delavnica delavnica = new Tretja.Delavnica(new Tretja.Delavec[]{
            new Tretja.Delavec("Bojan Ivnik", 534),
            new Tretja.Delavec("Branka Golob", 675),
            new Tretja.Delavec("Gabrijela Urlep", 7),
            new Tretja.Delavec("Simon Novak", 271),
            new Tretja.Delavec("Emil Vidic", 493),
            new Tretja.Delavec("Roman Lipnik", 41),
            new Tretja.Delavec("Branka Novak", 600),
            new Tretja.Delavec("Francka Furlan", 461),
            new Tretja.Delavec("Franci Han", 354),
            new Tretja.Delavec("Hilda Tanko", 563),
            new Tretja.Delavec("Cene Vidic", 200),
            new Tretja.Delavec("Nina Klasinc", 861),
            new Tretja.Delavec("Olga Vidic", 195),
            new Tretja.Delavec("Urban Pirc", 530),
            new Tretja.Delavec("Jana Sovinc", 86),
            new Tretja.Delavec("Bojan Sovinc", 882),
            new Tretja.Delavec("Dejan Ivnik", 823),
            new Tretja.Delavec("Nina Bevk", 943),
            new Tretja.Delavec("Ula Bevk", 62),
            new Tretja.Delavec("Maja Novak", 564),
            new Tretja.Delavec("Tanja Ermenc", 443),
            new Tretja.Delavec("Romana Lipnik", 999),
            new Tretja.Delavec("Eva Cevc", 760),
            new Tretja.Delavec("Zinka Cevc", 341),
            new Tretja.Delavec("Ivan Antolin", 929),
            new Tretja.Delavec("Vesna Debeljak", 671),
            new Tretja.Delavec("Ivan Jerman", 678),
            new Tretja.Delavec("Jana Jerman", 830),
            new Tretja.Delavec("Karel Jerman", 17),
            new Tretja.Delavec("Petra Sovinc", 369),
            new Tretja.Delavec("Karel Furlan", 525),
            new Tretja.Delavec("Roman Antolin", 398),
            new Tretja.Delavec("Andrej Furlan", 290),
            new Tretja.Delavec("Romana Pirc", 986),
            new Tretja.Delavec("Peter Lipnik", 23),
            new Tretja.Delavec("Simon Bevk", 412),
            new Tretja.Delavec("Dejan Klasinc", 404),
            new Tretja.Delavec("Andrej Vidic", 271),
            new Tretja.Delavec("Petra Antolin", 740),
            new Tretja.Delavec("Iva Ermenc", 512),
            new Tretja.Delavec("Cvetka Ivnik", 340),
            new Tretja.Delavec("Urban Oblak", 996),
            new Tretja.Delavec("Ana Ravnikar", 19),
            new Tretja.Delavec("Urban Golob", 73),
            new Tretja.Delavec("Urban Debeljak", 487),
            new Tretja.Delavec("Zinka Bevk", 256),
            new Tretja.Delavec("Petra Pirc", 334),
            new Tretja.Delavec("Nace Sovinc", 894),
            new Tretja.Delavec("Tilen Sovinc", 797),
            new Tretja.Delavec("Nace Golob", 800),
        });

        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1, p3, p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p4}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p6, p0, p3, p4}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p5, p3, p4}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p5, p6, p4, p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p2, p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3, p8}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3, p5}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p8, p4, p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p4, p6, p5}));
    }
}

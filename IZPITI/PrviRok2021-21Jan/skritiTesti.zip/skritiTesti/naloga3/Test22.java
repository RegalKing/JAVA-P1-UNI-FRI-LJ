
public class Test22 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 405);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 390);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 417);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 259);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 278);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 50);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 217);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 287);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 298);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 146);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 217);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 181);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 376);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 432);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 175);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 26);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 54);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 56);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 75);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 196);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 190);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 188);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 469);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 423);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 247);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 464);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 357);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 217);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 191);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 115);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 149);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o8, o12});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o11, o19, o21, o30});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o30, o21, o24, o6, o16});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o16});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o1, o22});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o25, o30});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o6, o5, o20, o11, o9});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o25, o12, o18, o3, o22});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o0, o7});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o17, o9});

        Tretja.Delavnica delavnica = new Tretja.Delavnica(new Tretja.Delavec[]{
            new Tretja.Delavec("Andrej Klasinc", 20),
            new Tretja.Delavec("Urban Pirc", 221),
            new Tretja.Delavec("Gabrijela Antolin", 602),
            new Tretja.Delavec("Ula Tanko", 333),
            new Tretja.Delavec("Vesna Oblak", 623),
            new Tretja.Delavec("Olga Tanko", 361),
            new Tretja.Delavec("Sonja Vidic", 685),
            new Tretja.Delavec("Branka Zorman", 749),
            new Tretja.Delavec("Roman Debeljak", 766),
            new Tretja.Delavec("Ula Zorman", 506),
            new Tretja.Delavec("Nace Ivnik", 641),
            new Tretja.Delavec("Karel Ravnikar", 411),
            new Tretja.Delavec("Francka Furlan", 378),
            new Tretja.Delavec("Andrej Ermenc", 161),
            new Tretja.Delavec("Karel Ermenc", 259),
            new Tretja.Delavec("Urban Mihevc", 149),
            new Tretja.Delavec("Petra Lipnik", 1),
            new Tretja.Delavec("Petra Jerman", 52),
            new Tretja.Delavec("Sonja Klasinc", 757),
            new Tretja.Delavec("Iva Debeljak", 733),
            new Tretja.Delavec("Peter Mihevc", 284),
            new Tretja.Delavec("Roman Vidic", 879),
            new Tretja.Delavec("Oton Lipnik", 530),
            new Tretja.Delavec("Andrej Ermenc", 989),
            new Tretja.Delavec("Petra Jerman", 893),
            new Tretja.Delavec("Tanja Bevk", 106),
            new Tretja.Delavec("Eva Sovinc", 24),
            new Tretja.Delavec("Maja Klasinc", 193),
            new Tretja.Delavec("Nace Vidic", 44),
            new Tretja.Delavec("Maja Debeljak", 8),
            new Tretja.Delavec("Lara Oblak", 964),
            new Tretja.Delavec("Cene Bevk", 483),
            new Tretja.Delavec("Hinko Urlep", 702),
            new Tretja.Delavec("Roman Ermenc", 255),
            new Tretja.Delavec("Leon Bevk", 315),
            new Tretja.Delavec("Gabrijela Ravnikar", 327),
            new Tretja.Delavec("Leon Cevc", 752),
            new Tretja.Delavec("Peter Ivnik", 801),
            new Tretja.Delavec("Sonja Ivnik", 696),
            new Tretja.Delavec("Vinko Tanko", 113),
            new Tretja.Delavec("Ula Ivnik", 369),
            new Tretja.Delavec("Tilen Tanko", 62),
        });

        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1, p0}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p2, p0, p5, p8, p1}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p2, p9, p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3, p5, p2}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p2, p5, p8, p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p7, p0, p9, p2, p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p3, p5, p7}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p2, p8, p4, p0, p9}));
    }
}

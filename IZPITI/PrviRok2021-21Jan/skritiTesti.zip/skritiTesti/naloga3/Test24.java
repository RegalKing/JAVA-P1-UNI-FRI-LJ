
public class Test24 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 150);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 126);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 255);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 222);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 322);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 236);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 204);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 77);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 223);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 382);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 413);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 278);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 181);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 241);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 491);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 314);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 348);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 3);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 392);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 326);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 255);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 18);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 121);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 439);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 136);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 286);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 251);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 236);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 54);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 36);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 369);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 33);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 136);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 215);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 420);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 285);
        Tretja.Opravilo o36 = new Tretja.Opravilo("o36", 488);
        Tretja.Opravilo o37 = new Tretja.Opravilo("o37", 77);
        Tretja.Opravilo o38 = new Tretja.Opravilo("o38", 157);
        Tretja.Opravilo o39 = new Tretja.Opravilo("o39", 482);
        Tretja.Opravilo o40 = new Tretja.Opravilo("o40", 289);
        Tretja.Opravilo o41 = new Tretja.Opravilo("o41", 249);
        Tretja.Opravilo o42 = new Tretja.Opravilo("o42", 62);
        Tretja.Opravilo o43 = new Tretja.Opravilo("o43", 23);
        Tretja.Opravilo o44 = new Tretja.Opravilo("o44", 197);
        Tretja.Opravilo o45 = new Tretja.Opravilo("o45", 40);
        Tretja.Opravilo o46 = new Tretja.Opravilo("o46", 457);
        Tretja.Opravilo o47 = new Tretja.Opravilo("o47", 309);
        Tretja.Opravilo o48 = new Tretja.Opravilo("o48", 3);
        Tretja.Opravilo o49 = new Tretja.Opravilo("o49", 278);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o46, o39, o0, o28, o16});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o8, o18, o12, o9, o35});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o25, o37, o28});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o0, o37, o8, o30, o25, o33, o4, o46, o34});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o36, o26, o22, o46, o5, o47, o18, o43, o42});

        Tretja.Delavnica delavnica = new Tretja.Delavnica(new Tretja.Delavec[]{
            new Tretja.Delavec("Ivan Novak", 158),
            new Tretja.Delavec("Simon Pirc", 17),
            new Tretja.Delavec("Zinka Antolin", 391),
            new Tretja.Delavec("Cene Bevk", 251),
            new Tretja.Delavec("Francka Vidic", 910),
            new Tretja.Delavec("Ivan Vidic", 167),
            new Tretja.Delavec("Hilda Urlep", 827),
            new Tretja.Delavec("Janez Ravnikar", 432),
            new Tretja.Delavec("Urban Tanko", 833),
            new Tretja.Delavec("Leon Jerman", 910),
            new Tretja.Delavec("Tanja Sovinc", 719),
            new Tretja.Delavec("Tanja Ermenc", 864),
            new Tretja.Delavec("Peter Oblak", 275),
            new Tretja.Delavec("Nina Han", 451),
            new Tretja.Delavec("Hilda Vidic", 938),
            new Tretja.Delavec("Iva Ermenc", 654),
            new Tretja.Delavec("Simon Han", 535),
            new Tretja.Delavec("Andrej Sovinc", 120),
            new Tretja.Delavec("Emil Bevk", 207),
            new Tretja.Delavec("Bojan Mihevc", 965),
            new Tretja.Delavec("Maja Mihevc", 641),
            new Tretja.Delavec("Karel Zorman", 650),
            new Tretja.Delavec("Ivan Antolin", 249),
            new Tretja.Delavec("Vesna Novak", 822),
            new Tretja.Delavec("Cene Mihevc", 702),
            new Tretja.Delavec("Oton Tanko", 11),
            new Tretja.Delavec("Hinko Debeljak", 876),
            new Tretja.Delavec("Gregor Antolin", 171),
            new Tretja.Delavec("Maja Debeljak", 629),
            new Tretja.Delavec("Branka Ermenc", 438),
            new Tretja.Delavec("Simon Ravnikar", 53),
            new Tretja.Delavec("Janez Tanko", 911),
            new Tretja.Delavec("Zoran Han", 295),
            new Tretja.Delavec("Lara Tanko", 406),
            new Tretja.Delavec("Lara Mihevc", 789),
            new Tretja.Delavec("Emil Jerman", 517),
            new Tretja.Delavec("Hinko Sovinc", 220),
            new Tretja.Delavec("Hinko Antolin", 831),
            new Tretja.Delavec("Branka Ermenc", 755),
            new Tretja.Delavec("Cvetka Zorman", 621),
        });

        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1, p0}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p4, p2}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p2}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p4, p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p4, p2}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1, p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1}));
    }
}

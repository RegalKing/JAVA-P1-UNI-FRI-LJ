
public class Test12 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 686);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 407);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 364);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 474);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 70);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 772);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 756);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 472);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 918);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 210);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 462);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 92);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 131);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 550);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 443);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 149);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 798);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 750);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 130);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 282);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 916);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 484);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 93);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 334);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 569);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 662);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 796);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 44);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 240);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 467);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 369);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 406);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 2);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 734);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 429);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 133);
        Tretja.Opravilo o36 = new Tretja.Opravilo("o36", 305);
        Tretja.Opravilo o37 = new Tretja.Opravilo("o37", 480);
        Tretja.Opravilo o38 = new Tretja.Opravilo("o38", 76);
        Tretja.Opravilo o39 = new Tretja.Opravilo("o39", 360);
        Tretja.Opravilo o40 = new Tretja.Opravilo("o40", 430);
        Tretja.Opravilo o41 = new Tretja.Opravilo("o41", 573);
        Tretja.Opravilo o42 = new Tretja.Opravilo("o42", 811);
        Tretja.Opravilo o43 = new Tretja.Opravilo("o43", 937);
        Tretja.Opravilo o44 = new Tretja.Opravilo("o44", 514);
        Tretja.Opravilo o45 = new Tretja.Opravilo("o45", 624);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o16, o45, o44, o43});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o16, o41, o43, o6, o7, o29, o38, o9});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o42, o3});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o8, o45, o5, o33});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o38, o21, o1, o28, o39, o13, o29, o22, o25, o14, o17, o30});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o39, o15, o37, o38, o34, o3, o16, o11, o24, o4, o1});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o36, o39, o2, o30});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o12, o8, o42, o32, o25, o22, o31, o7, o0, o27});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o17, o41, o31, o42, o45, o26, o0, o27, o40, o2, o20});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o31, o37, o19, o25, o6, o14, o38, o1, o42, o21});
        Tretja.Projekt p10 = new Tretja.Projekt("p10", new Tretja.Opravilo[]{o22, o27, o25, o17, o3, o31, o26, o4, o43, o33, o35, o12, o34, o13});
        Tretja.Projekt p11 = new Tretja.Projekt("p11", new Tretja.Opravilo[]{o42, o1, o17, o24});
        Tretja.Projekt p12 = new Tretja.Projekt("p12", new Tretja.Opravilo[]{o30, o33, o22, o36});

        System.out.println(p0.zahtevnost());
        System.out.println(p1.zahtevnost());
        System.out.println(p2.zahtevnost());
        System.out.println(p3.zahtevnost());
        System.out.println(p4.zahtevnost());
        System.out.println(p5.zahtevnost());
        System.out.println(p6.zahtevnost());
        System.out.println(p7.zahtevnost());
        System.out.println(p8.zahtevnost());
        System.out.println(p9.zahtevnost());
        System.out.println(p10.zahtevnost());
        System.out.println(p11.zahtevnost());
        System.out.println(p12.zahtevnost());
    }
}

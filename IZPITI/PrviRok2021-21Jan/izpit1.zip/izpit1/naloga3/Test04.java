
public class Test04 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 488);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 175);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 247);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 254);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 454);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 221);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 2);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 463);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 439);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 499);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 279);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 291);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 188);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 481);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 106);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 291);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 472);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 323);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 264);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 399);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 115);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 434);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 376);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 284);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 136);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 364);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 24);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 414);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 238);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 172);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 36);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 445);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 202);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 351);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 35);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 229);
        Tretja.Opravilo o36 = new Tretja.Opravilo("o36", 83);
        Tretja.Opravilo o37 = new Tretja.Opravilo("o37", 479);
        Tretja.Opravilo o38 = new Tretja.Opravilo("o38", 216);
        Tretja.Opravilo o39 = new Tretja.Opravilo("o39", 378);
        Tretja.Opravilo o40 = new Tretja.Opravilo("o40", 433);
        Tretja.Opravilo o41 = new Tretja.Opravilo("o41", 93);
        Tretja.Opravilo o42 = new Tretja.Opravilo("o42", 274);
        Tretja.Opravilo o43 = new Tretja.Opravilo("o43", 295);
        Tretja.Opravilo o44 = new Tretja.Opravilo("o44", 240);
        Tretja.Opravilo o45 = new Tretja.Opravilo("o45", 319);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o20, o19, o38, o15, o34, o14, o28, o40});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o43, o40, o38, o7, o26});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o33, o26, o37, o21});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o44, o29, o24, o14, o11, o1, o23, o37, o19});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o42, o11});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o15, o19, o28, o17});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o42, o5, o23, o38, o18, o24});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o42, o43});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o26, o44, o18, o17, o28, o4});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o35, o4, o45, o17, o13, o43, o22});
        Tretja.Projekt p10 = new Tretja.Projekt("p10", new Tretja.Opravilo[]{o36, o33, o21, o5, o41, o29});
        Tretja.Projekt p11 = new Tretja.Projekt("p11", new Tretja.Opravilo[]{o15, o9, o44, o27, o6, o45, o8, o33});
        Tretja.Projekt p12 = new Tretja.Projekt("p12", new Tretja.Opravilo[]{o45});

        Tretja.Delavnica delavnica = new Tretja.Delavnica(new Tretja.Delavec[]{
            new Tretja.Delavec("Vinko Jerman", 602),
            new Tretja.Delavec("Cene Ivnik", 572),
            new Tretja.Delavec("Ana Furlan", 625),
            new Tretja.Delavec("Romana Sovinc", 65),
            new Tretja.Delavec("Sonja Novak", 133),
            new Tretja.Delavec("Tanja Lipnik", 867),
            new Tretja.Delavec("Vinko Tanko", 308),
            new Tretja.Delavec("Bojan Sovinc", 201),
            new Tretja.Delavec("Branka Jerman", 542),
            new Tretja.Delavec("Cene Furlan", 903),
            new Tretja.Delavec("Vinko Klasinc", 554),
            new Tretja.Delavec("Gregor Golob", 909),
            new Tretja.Delavec("Bojan Furlan", 436),
            new Tretja.Delavec("Leon Bevk", 408),
            new Tretja.Delavec("Branka Ravnikar", 770),
            new Tretja.Delavec("Zoran Lipnik", 648),
            new Tretja.Delavec("Zoran Han", 18),
            new Tretja.Delavec("Andrej Bevk", 49),
            new Tretja.Delavec("Tanja Sovinc", 940),
            new Tretja.Delavec("Urban Sovinc", 255),
            new Tretja.Delavec("Hinko Urlep", 610),
            new Tretja.Delavec("Oton Furlan", 575),
            new Tretja.Delavec("Nina Golob", 206),
            new Tretja.Delavec("Eva Mihevc", 70),
            new Tretja.Delavec("Branka Golob", 568),
            new Tretja.Delavec("Petra Tanko", 878),
            new Tretja.Delavec("Romana Golob", 766),
            new Tretja.Delavec("Iva Klasinc", 516),
            new Tretja.Delavec("Franci Golob", 497),
            new Tretja.Delavec("Romana Furlan", 846),
            new Tretja.Delavec("Hilda Furlan", 322),
            new Tretja.Delavec("Iva Lipnik", 824),
            new Tretja.Delavec("Vesna Novak", 60),
            new Tretja.Delavec("Ula Urlep", 775),
            new Tretja.Delavec("Peter Lipnik", 170),
            new Tretja.Delavec("Petra Tanko", 592),
            new Tretja.Delavec("Hilda Jerman", 988),
            new Tretja.Delavec("Zoran Urlep", 850),
            new Tretja.Delavec("Jana Golob", 560),
            new Tretja.Delavec("Cvetka Tanko", 882),
        });

        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p0, p11, p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p8}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p8, p12}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p5, p12}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p7, p5, p10, p8, p3}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p6}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p10}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p11, p5, p2, p9, p8}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p1, p9, p6, p11}));
        System.out.println(delavnica.univerzalci(new Tretja.Projekt[]{p10, p4, p11, p5, p3}));
    }
}


public class Test02 {

    public static void main(String[] args) {
        Tretja.Opravilo o0 = new Tretja.Opravilo("o0", 393);
        Tretja.Opravilo o1 = new Tretja.Opravilo("o1", 853);
        Tretja.Opravilo o2 = new Tretja.Opravilo("o2", 629);
        Tretja.Opravilo o3 = new Tretja.Opravilo("o3", 482);
        Tretja.Opravilo o4 = new Tretja.Opravilo("o4", 864);
        Tretja.Opravilo o5 = new Tretja.Opravilo("o5", 318);
        Tretja.Opravilo o6 = new Tretja.Opravilo("o6", 995);
        Tretja.Opravilo o7 = new Tretja.Opravilo("o7", 123);
        Tretja.Opravilo o8 = new Tretja.Opravilo("o8", 18);
        Tretja.Opravilo o9 = new Tretja.Opravilo("o9", 535);
        Tretja.Opravilo o10 = new Tretja.Opravilo("o10", 74);
        Tretja.Opravilo o11 = new Tretja.Opravilo("o11", 970);
        Tretja.Opravilo o12 = new Tretja.Opravilo("o12", 216);
        Tretja.Opravilo o13 = new Tretja.Opravilo("o13", 918);
        Tretja.Opravilo o14 = new Tretja.Opravilo("o14", 308);
        Tretja.Opravilo o15 = new Tretja.Opravilo("o15", 823);
        Tretja.Opravilo o16 = new Tretja.Opravilo("o16", 334);
        Tretja.Opravilo o17 = new Tretja.Opravilo("o17", 570);
        Tretja.Opravilo o18 = new Tretja.Opravilo("o18", 931);
        Tretja.Opravilo o19 = new Tretja.Opravilo("o19", 399);
        Tretja.Opravilo o20 = new Tretja.Opravilo("o20", 549);
        Tretja.Opravilo o21 = new Tretja.Opravilo("o21", 56);
        Tretja.Opravilo o22 = new Tretja.Opravilo("o22", 737);
        Tretja.Opravilo o23 = new Tretja.Opravilo("o23", 998);
        Tretja.Opravilo o24 = new Tretja.Opravilo("o24", 952);
        Tretja.Opravilo o25 = new Tretja.Opravilo("o25", 251);
        Tretja.Opravilo o26 = new Tretja.Opravilo("o26", 769);
        Tretja.Opravilo o27 = new Tretja.Opravilo("o27", 189);
        Tretja.Opravilo o28 = new Tretja.Opravilo("o28", 461);
        Tretja.Opravilo o29 = new Tretja.Opravilo("o29", 377);
        Tretja.Opravilo o30 = new Tretja.Opravilo("o30", 717);
        Tretja.Opravilo o31 = new Tretja.Opravilo("o31", 640);
        Tretja.Opravilo o32 = new Tretja.Opravilo("o32", 147);
        Tretja.Opravilo o33 = new Tretja.Opravilo("o33", 707);
        Tretja.Opravilo o34 = new Tretja.Opravilo("o34", 560);
        Tretja.Opravilo o35 = new Tretja.Opravilo("o35", 10);
        Tretja.Opravilo o36 = new Tretja.Opravilo("o36", 657);
        Tretja.Opravilo o37 = new Tretja.Opravilo("o37", 939);
        Tretja.Opravilo o38 = new Tretja.Opravilo("o38", 428);
        Tretja.Opravilo o39 = new Tretja.Opravilo("o39", 382);
        Tretja.Opravilo o40 = new Tretja.Opravilo("o40", 536);
        Tretja.Opravilo o41 = new Tretja.Opravilo("o41", 346);
        Tretja.Opravilo o42 = new Tretja.Opravilo("o42", 394);
        Tretja.Opravilo o43 = new Tretja.Opravilo("o43", 539);
        Tretja.Opravilo o44 = new Tretja.Opravilo("o44", 395);
        Tretja.Opravilo o45 = new Tretja.Opravilo("o45", 24);
        Tretja.Opravilo o46 = new Tretja.Opravilo("o46", 200);
        Tretja.Opravilo o47 = new Tretja.Opravilo("o47", 676);
        Tretja.Opravilo o48 = new Tretja.Opravilo("o48", 83);
        Tretja.Opravilo o49 = new Tretja.Opravilo("o49", 427);

        Tretja.Projekt p0 = new Tretja.Projekt("p0", new Tretja.Opravilo[]{o39, o25, o11, o2});
        Tretja.Projekt p1 = new Tretja.Projekt("p1", new Tretja.Opravilo[]{o7});
        Tretja.Projekt p2 = new Tretja.Projekt("p2", new Tretja.Opravilo[]{o7, o48, o34, o31, o38, o24, o2, o26, o33});
        Tretja.Projekt p3 = new Tretja.Projekt("p3", new Tretja.Opravilo[]{o15, o46, o28, o22, o1, o6});
        Tretja.Projekt p4 = new Tretja.Projekt("p4", new Tretja.Opravilo[]{o5, o26, o34});
        Tretja.Projekt p5 = new Tretja.Projekt("p5", new Tretja.Opravilo[]{o43, o22, o31, o34, o6, o10, o13});
        Tretja.Projekt p6 = new Tretja.Projekt("p6", new Tretja.Opravilo[]{o14, o3, o16, o44, o18, o13, o48, o26, o24, o37, o8, o6});
        Tretja.Projekt p7 = new Tretja.Projekt("p7", new Tretja.Opravilo[]{o0, o13, o41, o36, o31, o7, o28, o20, o34, o12, o10, o11, o18, o16});
        Tretja.Projekt p8 = new Tretja.Projekt("p8", new Tretja.Opravilo[]{o15, o19});
        Tretja.Projekt p9 = new Tretja.Projekt("p9", new Tretja.Opravilo[]{o33, o35, o19, o46, o41, o16, o7, o27, o38, o30, o0, o13, o48});
        Tretja.Projekt p10 = new Tretja.Projekt("p10", new Tretja.Opravilo[]{o35, o12, o7, o11, o15, o42, o4, o9, o10, o24, o19, o18, o36, o39});
        Tretja.Projekt p11 = new Tretja.Projekt("p11", new Tretja.Opravilo[]{o8, o34, o2, o9, o10, o4});

        System.out.println(p0.zahtevnost());
        System.out.println(p1.zahtevnost());
        System.out.println(p2.zahtevnost());
        System.out.println(p3.zahtevnost());
        System.out.println(p4.zahtevnost());
        System.out.println(p5.zahtevnost());
        System.out.println(p6.zahtevnost());
        System.out.println(p7.zahtevnost());
        System.out.println(p8.zahtevnost());
        System.out.println(p9.zahtevnost());
        System.out.println(p10.zahtevnost());
        System.out.println(p11.zahtevnost());
    }
}


/*
 * Testiranje:
 *
 * tj.exe
 */

import java.util.*;

public class Druga {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }

    public static int stPresezkov(int[][] r, int meja) {
        // popravite / dopolnite ...
        return -9999;
    }

    public static int nedeljskoPovprecje(int[][] r) {
        // popravite / dopolnite ...
        return -9999;
    }
}

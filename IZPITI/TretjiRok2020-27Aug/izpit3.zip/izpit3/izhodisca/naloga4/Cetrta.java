
/*
 * Testiranje:
 *
 * tj.exe
 */

import java.util.*;

public class Cetrta {

    public static interface Generator {
        public int naslednji();
    }

    public static int stKlicev(Generator gen, int k) {
        // popravite / dopolnite ...
        return -9999;
    }

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }
}

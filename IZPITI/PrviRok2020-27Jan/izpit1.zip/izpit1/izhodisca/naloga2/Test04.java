
public class Test04 {

    public static void main(String[] args) {
        int[][] t = {
            { 3943 },
            { 9680 },
            { 1056 },
            { 1607 },
            { 3367 },
            { 4384 },
            { 5283 },
            {  654 },
            { 8166 },
            { 7464 },
            { 4113 },
            { 4417 },
            { 5251 },
            { 3504 },
            { 8689 },
            { 3319 },
            {  227 },
            { 3338 },
            { 4552 },
            { 7196 },
        };

        for (int krog = 0;  krog < 1;  krog++) {
            System.out.println(Druga.najCas(t, krog));
        }
    }
}

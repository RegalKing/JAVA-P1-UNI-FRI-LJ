
/*
 * Testiranje:
 *
 * tj.exe
 */

import java.util.*;

public class Druga {

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po "zelji)
    }

    public static int najCas(int[][] t, int krog) {
        // popravite / dopolnite ...
        return -1;
    }

    public static int[][] kumulativa(int[][] t) {
        // popravite / dopolnite ...
        return null;
    }
}

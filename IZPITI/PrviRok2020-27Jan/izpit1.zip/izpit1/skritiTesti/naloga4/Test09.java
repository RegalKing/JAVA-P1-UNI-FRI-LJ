
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test09 {

    private static final boolean T = true;
    private static final boolean F = false;

    public static void main(String[] args) {
        List<Cetrta.Celica> celice = new ArrayList<>(Arrays.asList(
            new Cetrta.Celica(6, 11),
            new Cetrta.Celica(3, 1),
            new Cetrta.Celica(0, 3),
            new Cetrta.Celica(9, 12),
            new Cetrta.Celica(12, 8),
            new Cetrta.Celica(7, 7),
            new Cetrta.Celica(3, 12),
            new Cetrta.Celica(0, 9),
            new Cetrta.Celica(1, 12),
            new Cetrta.Celica(9, 1),
            new Cetrta.Celica(4, 8),
            new Cetrta.Celica(3, 10),
            new Cetrta.Celica(6, 4),
            new Cetrta.Celica(1, 4),
            new Cetrta.Celica(2, 6),
            new Cetrta.Celica(5, 8),
            new Cetrta.Celica(8, 5),
            new Cetrta.Celica(5, 3),
            new Cetrta.Celica(10, 7),
            new Cetrta.Celica(4, 2),
            new Cetrta.Celica(9, 6),
            new Cetrta.Celica(4, 11),
            new Cetrta.Celica(8, 8),
            new Cetrta.Celica(9, 5),
            new Cetrta.Celica(1, 8),
            new Cetrta.Celica(2, 11),
            new Cetrta.Celica(1, 11),
            new Cetrta.Celica(2, 8),
            new Cetrta.Celica(11, 5),
            new Cetrta.Celica(3, 2),
            new Cetrta.Celica(3, 9),
            new Cetrta.Celica(7, 8),
            new Cetrta.Celica(12, 1),
            new Cetrta.Celica(2, 0),
            new Cetrta.Celica(8, 2),
            new Cetrta.Celica(4, 3),
            new Cetrta.Celica(4, 7),
            new Cetrta.Celica(3, 4),
            new Cetrta.Celica(7, 5),
            new Cetrta.Celica(6, 8),
            new Cetrta.Celica(5, 7),
            new Cetrta.Celica(2, 12),
            new Cetrta.Celica(5, 12),
            new Cetrta.Celica(9, 3),
            new Cetrta.Celica(10, 9),
            new Cetrta.Celica(11, 0),
            new Cetrta.Celica(0, 12),
            new Cetrta.Celica(0, 2),
            new Cetrta.Celica(7, 10),
            new Cetrta.Celica(8, 0),
            new Cetrta.Celica(11, 6),
            new Cetrta.Celica(11, 12),
            new Cetrta.Celica(12, 7),
            new Cetrta.Celica(4, 12),
            new Cetrta.Celica(10, 5),
            new Cetrta.Celica(7, 12),
            new Cetrta.Celica(7, 9),
            new Cetrta.Celica(7, 4),
            new Cetrta.Celica(6, 7),
            new Cetrta.Celica(7, 3),
            new Cetrta.Celica(8, 1),
            new Cetrta.Celica(5, 0),
            new Cetrta.Celica(2, 4),
            new Cetrta.Celica(2, 1),
            new Cetrta.Celica(6, 12),
            new Cetrta.Celica(5, 1),
            new Cetrta.Celica(3, 11),
            new Cetrta.Celica(10, 10),
            new Cetrta.Celica(11, 4),
            new Cetrta.Celica(1, 1),
            new Cetrta.Celica(8, 9),
            new Cetrta.Celica(7, 1)
        ));
        celice.sort(null);
        System.out.println(celice);
    }
}

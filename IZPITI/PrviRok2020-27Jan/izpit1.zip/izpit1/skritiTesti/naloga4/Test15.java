
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Test15 {

    private static final boolean T = true;
    private static final boolean F = false;

    public static void main(String[] args) {
        List<Cetrta.Celica> celice = new ArrayList<>(Arrays.asList(
            new Cetrta.Celica(0, 0),
            new Cetrta.Celica(2, 10),
            new Cetrta.Celica(7, 5),
            new Cetrta.Celica(9, 9),
            new Cetrta.Celica(8, 14),
            new Cetrta.Celica(4, 14),
            new Cetrta.Celica(0, 7),
            new Cetrta.Celica(3, 1),
            new Cetrta.Celica(9, 1),
            new Cetrta.Celica(7, 8),
            new Cetrta.Celica(9, 7),
            new Cetrta.Celica(2, 12),
            new Cetrta.Celica(5, 0),
            new Cetrta.Celica(5, 1),
            new Cetrta.Celica(14, 14),
            new Cetrta.Celica(5, 7),
            new Cetrta.Celica(2, 8),
            new Cetrta.Celica(11, 0),
            new Cetrta.Celica(14, 2),
            new Cetrta.Celica(13, 5),
            new Cetrta.Celica(6, 2),
            new Cetrta.Celica(4, 9),
            new Cetrta.Celica(4, 2),
            new Cetrta.Celica(1, 8),
            new Cetrta.Celica(7, 10),
            new Cetrta.Celica(9, 13),
            new Cetrta.Celica(4, 3),
            new Cetrta.Celica(4, 7),
            new Cetrta.Celica(4, 6),
            new Cetrta.Celica(13, 0),
            new Cetrta.Celica(10, 8),
            new Cetrta.Celica(12, 10),
            new Cetrta.Celica(6, 14),
            new Cetrta.Celica(9, 4),
            new Cetrta.Celica(0, 1),
            new Cetrta.Celica(13, 3),
            new Cetrta.Celica(1, 9),
            new Cetrta.Celica(9, 12),
            new Cetrta.Celica(10, 2),
            new Cetrta.Celica(11, 11),
            new Cetrta.Celica(1, 13),
            new Cetrta.Celica(14, 13),
            new Cetrta.Celica(7, 0),
            new Cetrta.Celica(7, 6),
            new Cetrta.Celica(13, 2),
            new Cetrta.Celica(12, 12),
            new Cetrta.Celica(10, 1),
            new Cetrta.Celica(12, 11),
            new Cetrta.Celica(14, 0),
            new Cetrta.Celica(11, 13),
            new Cetrta.Celica(2, 14),
            new Cetrta.Celica(14, 8),
            new Cetrta.Celica(11, 9),
            new Cetrta.Celica(7, 14),
            new Cetrta.Celica(3, 12),
            new Cetrta.Celica(2, 4),
            new Cetrta.Celica(11, 3),
            new Cetrta.Celica(4, 12),
            new Cetrta.Celica(3, 6),
            new Cetrta.Celica(13, 9),
            new Cetrta.Celica(3, 4),
            new Cetrta.Celica(10, 11),
            new Cetrta.Celica(0, 12),
            new Cetrta.Celica(3, 9),
            new Cetrta.Celica(3, 2),
            new Cetrta.Celica(1, 3),
            new Cetrta.Celica(10, 7),
            new Cetrta.Celica(1, 11),
            new Cetrta.Celica(1, 4)
        ));
        celice.sort(null);
        System.out.println(celice);
    }
}

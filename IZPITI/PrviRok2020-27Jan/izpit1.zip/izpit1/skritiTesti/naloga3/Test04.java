
public class Test04 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 6910, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 3780, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 4442, v001);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 9062, v001);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 3046, null);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 7649, v002);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 2447, v002);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 5642, v006);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 5255, v006);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 3890, v001);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 9871, null);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 2911, v002);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 6050, v000);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 9844, v009);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 1757, v006);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 9812, v001);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 6631, v011);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 6019, v008);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 6985, v014);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 2514, null);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 7825, v009);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 9129, v018);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 1038, v011);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 5452, v011);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 3528, v022);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 8554, v012);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 1347, null);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 3465, v007);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 9149, v011);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 1457, v016);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 6032, v029);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 3319, v005);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 7099, v012);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 8965, v025);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 6314, v030);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 5075, null);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 3512, null);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 2472, null);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 2780, null);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 9228, v036);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 9593, v007);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 1471, v038);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 9361, v031);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 4957, null);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 8340, null);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 5138, v037);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 2871, v013);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 3692, v024);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 1677, v000);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 3842, v007);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 4407, v003);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 7664, v002);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 8354, v041);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 6877, null);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 9004, null);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 8234, v037);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 9193, v015);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 7408, null);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 6147, v034);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 3063, v016);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 3336, v029);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 6303, v040);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 9109, v033);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 5832, v027);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 7968, v000);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 5181, v023);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 5029, v015);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 5412, v020);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 5388, v030);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 7366, null);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 3001, v008);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 3847, null);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 6549, v015);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 6750, v002);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 6704, v030);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 8357, v008);
        Tretja.Delavec d031 = new Tretja.Delavec("d031", 1861, v040);
        Tretja.Delavec d032 = new Tretja.Delavec("d032", 4624, v018);
        Tretja.Delavec d033 = new Tretja.Delavec("d033", 1304, v009);
        Tretja.Delavec d034 = new Tretja.Delavec("d034", 1044, v033);
        Tretja.Delavec d035 = new Tretja.Delavec("d035", 3696, v044);
        Tretja.Delavec d036 = new Tretja.Delavec("d036", 6718, v030);
        Tretja.Delavec d037 = new Tretja.Delavec("d037", 9423, v027);
        Tretja.Delavec d038 = new Tretja.Delavec("d038", 3354, v039);
        Tretja.Delavec d039 = new Tretja.Delavec("d039", 7669, null);

        Tretja.Zaposleni[] zaposleni = {
            v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043, v044,
            d000, d001, d002, d003, d004, d005, d006, d007, d008, d009, d010, d011, d012, d013, d014, d015, d016, d017, d018, d019, d020, d021, d022, d023, d024, d025, d026, d027, d028, d029, d030, d031, d032, d033, d034, d035, d036, d037, d038, d039
        };

        System.out.println("[ placaNadrejenega ]");
        for (Tretja.Zaposleni z: zaposleni) {
            System.out.printf("%s -> %d%n", z, z.placaNadrejenega());
        }
    }
}

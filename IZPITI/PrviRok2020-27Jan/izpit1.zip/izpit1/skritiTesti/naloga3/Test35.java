
public class Test35 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 3374, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 7040, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 7022, v000);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 1849, v001);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 2564, v002);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 4978, v003);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 7625, v005);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 7154, v004);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 4317, v004);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 7193, v007);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 1026, v002);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 1331, v005);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 7616, v006);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 3366, v004);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 9141, null);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 5253, v012);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 7953, v007);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 8446, v001);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 9035, v000);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 6468, v007);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 7988, null);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 7607, v010);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 6062, v018);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 8129, v015);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 1654, v022);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 2800, null);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 6000, v002);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 7865, v005);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 8462, v007);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 1826, v006);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 9767, v027);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 1740, v015);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 2338, null);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 6442, v025);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 6705, v023);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 3416, v034);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 3606, null);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 5671, v001);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 1273, null);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 1051, v000);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 9944, v011);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 4570, v033);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 1993, v023);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 6217, v005);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 5549, v012);
        Tretja.Vodja v045 = new Tretja.Vodja("v045", 5065, null);
        Tretja.Vodja v046 = new Tretja.Vodja("v046", 4051, v035);
        Tretja.Vodja v047 = new Tretja.Vodja("v047", 2280, v042);
        Tretja.Vodja v048 = new Tretja.Vodja("v048", 3196, v036);
        Tretja.Vodja v049 = new Tretja.Vodja("v049", 6518, v030);
        Tretja.Vodja v050 = new Tretja.Vodja("v050", 4207, v043);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 5626, v010);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 2437, v032);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 1442, v005);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 8678, v036);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 8445, v025);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 5876, v028);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 4371, v050);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 2819, v039);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 2323, v034);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 1628, v034);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 2377, v013);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 5657, v008);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 9448, null);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 5861, v028);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 9336, v046);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 6866, v012);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 8022, v005);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 9159, v037);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 6095, v035);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 2075, v047);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 3907, v037);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 5227, v038);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 6686, v036);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 4452, v031);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 5224, v045);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 6098, v004);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 2671, v026);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 2623, null);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 4214, v021);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 7997, v027);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 7679, v009);

        Tretja.Zaposleni[] zaposleni = {v001, v035, d002, v010, d005, d017, v006, d022, d012, d030, v016, v044, d008, d029, v037, d007, d015, v018, d023, d025, v026, v036, v041, v030, v013, d024, v021, v048, d011, v047, v015, d003, d027, v029, v049, v038, v017, v008, v012, v022, v023, d004, v025, v003, v034, d000, v045, d001, v040, v007, v031, d006, v050, v039, d013, v043, v032, d019, d018, v000, d026, v005, d014, v024, v011, v042, d028, v033, v020, d009, v028, d010, v027, v014, v019, d016, v009, d021, v002, d020, v046, v004};

        System.out.printf("steviloAnomalij = %d%n", Tretja.Zaposleni.steviloAnomalij(zaposleni));
    }
}

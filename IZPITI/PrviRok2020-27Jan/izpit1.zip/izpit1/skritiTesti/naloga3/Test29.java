
public class Test29 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 3990, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 5549, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 4532, null);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 4626, v001);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 5206, v001);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 8166, null);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 4043, v000);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 1225, v005);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 9451, v005);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 4278, v007);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 4969, v008);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 8051, null);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 1180, null);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 1616, v001);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 4947, v002);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 4422, v013);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 3413, v015);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 6836, v003);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 8208, v002);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 8907, v013);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 8193, v010);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 3929, v017);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 7117, null);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 4346, v002);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 7491, v023);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 2767, null);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 4899, v025);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 1760, v016);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 2930, null);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 3577, v011);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 2116, null);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 7100, v003);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 6688, v001);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 3777, v029);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 8433, null);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 4046, v000);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 8332, v031);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 1539, v033);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 9861, v035);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 4619, v033);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 1410, v014);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 1740, v004);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 5896, v039);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 9125, v027);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 5781, v028);
        Tretja.Vodja v045 = new Tretja.Vodja("v045", 5708, v044);
        Tretja.Vodja v046 = new Tretja.Vodja("v046", 3879, v012);
        Tretja.Vodja v047 = new Tretja.Vodja("v047", 7059, v018);
        Tretja.Vodja v048 = new Tretja.Vodja("v048", 1334, v028);
        Tretja.Vodja v049 = new Tretja.Vodja("v049", 8473, v004);
        Tretja.Vodja v050 = new Tretja.Vodja("v050", 5089, v023);
        Tretja.Vodja v051 = new Tretja.Vodja("v051", 3926, v036);
        Tretja.Vodja v052 = new Tretja.Vodja("v052", 6727, null);
        Tretja.Vodja v053 = new Tretja.Vodja("v053", 3865, null);
        Tretja.Vodja v054 = new Tretja.Vodja("v054", 4717, v035);
        Tretja.Vodja v055 = new Tretja.Vodja("v055", 7287, null);
        Tretja.Vodja v056 = new Tretja.Vodja("v056", 1188, v024);
        Tretja.Vodja v057 = new Tretja.Vodja("v057", 5717, v029);
        Tretja.Vodja v058 = new Tretja.Vodja("v058", 1085, v052);
        Tretja.Vodja v059 = new Tretja.Vodja("v059", 7138, v012);
        Tretja.Vodja v060 = new Tretja.Vodja("v060", 1697, v041);
        Tretja.Vodja v061 = new Tretja.Vodja("v061", 9893, v015);
        Tretja.Vodja v062 = new Tretja.Vodja("v062", 7109, v042);
        Tretja.Vodja v063 = new Tretja.Vodja("v063", 8614, null);
        Tretja.Vodja v064 = new Tretja.Vodja("v064", 8163, v043);
        Tretja.Vodja v065 = new Tretja.Vodja("v065", 2173, null);
        Tretja.Vodja v066 = new Tretja.Vodja("v066", 8376, v026);
        Tretja.Vodja v067 = new Tretja.Vodja("v067", 7769, v020);
        Tretja.Vodja v068 = new Tretja.Vodja("v068", 2324, null);
        Tretja.Vodja v069 = new Tretja.Vodja("v069", 5218, v011);
        Tretja.Vodja v070 = new Tretja.Vodja("v070", 8641, null);
        Tretja.Vodja v071 = new Tretja.Vodja("v071", 4544, v061);
        Tretja.Vodja v072 = new Tretja.Vodja("v072", 7311, null);
        Tretja.Vodja v073 = new Tretja.Vodja("v073", 6172, v003);
        Tretja.Vodja v074 = new Tretja.Vodja("v074", 2909, null);
        Tretja.Vodja v075 = new Tretja.Vodja("v075", 4977, null);
        Tretja.Vodja v076 = new Tretja.Vodja("v076", 3375, v005);
        Tretja.Vodja v077 = new Tretja.Vodja("v077", 7382, v026);
        Tretja.Vodja v078 = new Tretja.Vodja("v078", 5134, v027);

        Tretja.Vodja[] vodje = {v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043, v044, v045, v046, v047, v048, v049, v050, v051, v052, v053, v054, v055, v056, v057, v058, v059, v060, v061, v062, v063, v064, v065, v066, v067, v068, v069, v070, v071, v072, v073, v074, v075, v076, v077, v078};

        System.out.println("[ vrhovni ]");
        for (Tretja.Vodja v: vodje) {
            System.out.printf("%s -> %s%n", v, v.vrhovni());
        }
    }
}

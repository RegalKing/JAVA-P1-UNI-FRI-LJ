
public class Test27 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 8022, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 6236, null);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 3901, v000);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 1531, v002);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 4280, v001);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 8674, v003);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 5630, v002);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 3828, v002);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 9647, v004);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 4918, v001);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 8280, v008);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 7113, v010);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 2409, v009);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 5377, v010);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 6092, v006);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 1764, v011);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 6948, v000);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 4345, v010);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 2171, v013);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 9755, v000);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 1338, v009);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 5744, v013);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 4199, v017);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 2385, v010);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 4879, v010);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 2321, v021);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 5180, v020);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 9300, v003);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 7194, v010);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 1577, v001);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 7643, v010);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 5512, v011);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 3411, v020);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 2564, v030);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 8008, v016);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 5998, v033);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 3830, v002);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 9310, v018);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 1472, v012);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 5881, v012);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 4968, v011);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 8139, v023);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 1162, v028);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 3335, v002);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 9182, v037);
        Tretja.Vodja v045 = new Tretja.Vodja("v045", 2286, v041);
        Tretja.Vodja v046 = new Tretja.Vodja("v046", 6281, v012);
        Tretja.Vodja v047 = new Tretja.Vodja("v047", 2855, null);
        Tretja.Vodja v048 = new Tretja.Vodja("v048", 6196, v042);
        Tretja.Vodja v049 = new Tretja.Vodja("v049", 4290, v042);
        Tretja.Vodja v050 = new Tretja.Vodja("v050", 8724, v039);
        Tretja.Vodja v051 = new Tretja.Vodja("v051", 3981, v027);
        Tretja.Vodja v052 = new Tretja.Vodja("v052", 4100, v022);
        Tretja.Vodja v053 = new Tretja.Vodja("v053", 2155, v047);
        Tretja.Vodja v054 = new Tretja.Vodja("v054", 4719, null);
        Tretja.Vodja v055 = new Tretja.Vodja("v055", 6435, v049);
        Tretja.Vodja v056 = new Tretja.Vodja("v056", 2696, v024);
        Tretja.Vodja v057 = new Tretja.Vodja("v057", 5898, v026);
        Tretja.Vodja v058 = new Tretja.Vodja("v058", 4672, v045);
        Tretja.Vodja v059 = new Tretja.Vodja("v059", 5056, v010);
        Tretja.Vodja v060 = new Tretja.Vodja("v060", 8165, v032);
        Tretja.Vodja v061 = new Tretja.Vodja("v061", 6936, v014);
        Tretja.Vodja v062 = new Tretja.Vodja("v062", 6825, v005);
        Tretja.Vodja v063 = new Tretja.Vodja("v063", 2039, v011);
        Tretja.Vodja v064 = new Tretja.Vodja("v064", 6928, v023);
        Tretja.Vodja v065 = new Tretja.Vodja("v065", 9587, v007);
        Tretja.Vodja v066 = new Tretja.Vodja("v066", 8766, v046);
        Tretja.Vodja v067 = new Tretja.Vodja("v067", 9982, v021);
        Tretja.Vodja v068 = new Tretja.Vodja("v068", 2689, v060);
        Tretja.Vodja v069 = new Tretja.Vodja("v069", 7539, v043);
        Tretja.Vodja v070 = new Tretja.Vodja("v070", 1316, v027);
        Tretja.Vodja v071 = new Tretja.Vodja("v071", 1489, v001);
        Tretja.Vodja v072 = new Tretja.Vodja("v072", 5886, v070);
        Tretja.Vodja v073 = new Tretja.Vodja("v073", 6827, v018);
        Tretja.Vodja v074 = new Tretja.Vodja("v074", 3836, v027);
        Tretja.Vodja v075 = new Tretja.Vodja("v075", 6269, v070);
        Tretja.Vodja v076 = new Tretja.Vodja("v076", 1739, v020);
        Tretja.Vodja v077 = new Tretja.Vodja("v077", 3059, v005);

        Tretja.Vodja[] vodje = {v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043, v044, v045, v046, v047, v048, v049, v050, v051, v052, v053, v054, v055, v056, v057, v058, v059, v060, v061, v062, v063, v064, v065, v066, v067, v068, v069, v070, v071, v072, v073, v074, v075, v076, v077};

        System.out.println("[ vrhovni ]");
        for (Tretja.Vodja v: vodje) {
            System.out.printf("%s -> %s%n", v, v.vrhovni());
        }
    }
}

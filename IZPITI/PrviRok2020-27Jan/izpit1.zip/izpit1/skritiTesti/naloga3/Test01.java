
public class Test01 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 8820, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 9359, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 6088, v000);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 8094, v002);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 2631, v000);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 4564, v003);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 1343, v001);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 3736, v006);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 1191, v006);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 2819, v008);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 7670, v001);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 6014, v001);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 4834, v009);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 3823, v001);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 7917, v005);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 7202, v006);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 8529, v011);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 8101, v013);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 2729, v009);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 9093, null);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 7575, null);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 2643, null);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 1337, null);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 8977, v007);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 5423, v007);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 6663, v016);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 2093, null);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 9786, v005);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 5747, v022);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 3828, null);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 5242, v003);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 4770, v025);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 9313, v008);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 9273, v003);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 5053, v008);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 1622, v011);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 5033, v001);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 1060, v008);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 8252, v000);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 4725, v013);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 2172, v012);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 8350, v024);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 2798, v022);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 9531, v000);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 6544, null);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 7779, v011);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 2539, v022);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 9577, v010);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 3976, v012);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 2634, v004);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 4866, v016);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 8814, v035);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 1884, v003);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 9673, v010);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 5474, v041);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 5178, v038);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 9955, v012);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 6094, v029);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 5287, v027);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 4892, v040);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 7511, v029);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 6663, v029);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 1067, v001);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 9588, v011);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 8412, v002);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 6411, v039);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 1964, v040);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 5242, v016);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 2364, v018);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 2176, v038);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 6212, v015);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 3434, v039);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 4390, v038);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 6248, v039);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 9716, v023);
        Tretja.Delavec d031 = new Tretja.Delavec("d031", 1471, v014);
        Tretja.Delavec d032 = new Tretja.Delavec("d032", 6274, v009);
        Tretja.Delavec d033 = new Tretja.Delavec("d033", 9498, v014);
        Tretja.Delavec d034 = new Tretja.Delavec("d034", 1278, v003);
        Tretja.Delavec d035 = new Tretja.Delavec("d035", 9907, v000);
        Tretja.Delavec d036 = new Tretja.Delavec("d036", 1113, v033);
        Tretja.Delavec d037 = new Tretja.Delavec("d037", 5762, v014);
        Tretja.Delavec d038 = new Tretja.Delavec("d038", 2294, v037);
        Tretja.Delavec d039 = new Tretja.Delavec("d039", 9784, v035);
        Tretja.Delavec d040 = new Tretja.Delavec("d040", 9163, null);
        Tretja.Delavec d041 = new Tretja.Delavec("d041", 4940, v039);
        Tretja.Delavec d042 = new Tretja.Delavec("d042", 4661, v036);
        Tretja.Delavec d043 = new Tretja.Delavec("d043", 3309, v010);
        Tretja.Delavec d044 = new Tretja.Delavec("d044", 3746, v018);
        Tretja.Delavec d045 = new Tretja.Delavec("d045", 9689, v037);
        Tretja.Delavec d046 = new Tretja.Delavec("d046", 4143, v017);
        Tretja.Delavec d047 = new Tretja.Delavec("d047", 7314, v008);
        Tretja.Delavec d048 = new Tretja.Delavec("d048", 4863, v020);
        Tretja.Delavec d049 = new Tretja.Delavec("d049", 2357, v027);
        Tretja.Delavec d050 = new Tretja.Delavec("d050", 7566, v029);
        Tretja.Delavec d051 = new Tretja.Delavec("d051", 6819, v020);
        Tretja.Delavec d052 = new Tretja.Delavec("d052", 6885, null);
        Tretja.Delavec d053 = new Tretja.Delavec("d053", 3738, v032);
        Tretja.Delavec d054 = new Tretja.Delavec("d054", 6442, v033);
        Tretja.Delavec d055 = new Tretja.Delavec("d055", 8617, v017);
        Tretja.Delavec d056 = new Tretja.Delavec("d056", 6915, v031);
        Tretja.Delavec d057 = new Tretja.Delavec("d057", 6494, v000);
        Tretja.Delavec d058 = new Tretja.Delavec("d058", 5684, v041);
        Tretja.Delavec d059 = new Tretja.Delavec("d059", 1190, null);
        Tretja.Delavec d060 = new Tretja.Delavec("d060", 9040, v006);
        Tretja.Delavec d061 = new Tretja.Delavec("d061", 5455, v021);
        Tretja.Delavec d062 = new Tretja.Delavec("d062", 7310, v018);
        Tretja.Delavec d063 = new Tretja.Delavec("d063", 9309, v028);
        Tretja.Delavec d064 = new Tretja.Delavec("d064", 1934, v027);
        Tretja.Delavec d065 = new Tretja.Delavec("d065", 7495, v016);
        Tretja.Delavec d066 = new Tretja.Delavec("d066", 2481, v017);
        Tretja.Delavec d067 = new Tretja.Delavec("d067", 5834, v033);

        Tretja.Zaposleni[] zaposleni = {
            v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043,
            d000, d001, d002, d003, d004, d005, d006, d007, d008, d009, d010, d011, d012, d013, d014, d015, d016, d017, d018, d019, d020, d021, d022, d023, d024, d025, d026, d027, d028, d029, d030, d031, d032, d033, d034, d035, d036, d037, d038, d039, d040, d041, d042, d043, d044, d045, d046, d047, d048, d049, d050, d051, d052, d053, d054, d055, d056, d057, d058, d059, d060, d061, d062, d063, d064, d065, d066, d067
        };

        System.out.println("[ placaNadrejenega ]");
        for (Tretja.Zaposleni z: zaposleni) {
            System.out.printf("%s -> %d%n", z, z.placaNadrejenega());
        }
    }
}

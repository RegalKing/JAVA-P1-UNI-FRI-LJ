
public class Test08 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 3377, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 9251, null);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 1600, v001);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 2056, v001);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 3238, v001);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 4934, v001);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 2297, v003);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 5849, v006);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 5606, null);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 9832, v000);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 4975, v009);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 4483, v010);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 4754, v005);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 3529, v009);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 6982, v008);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 1492, v008);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 1718, v006);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 9189, v002);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 8540, v008);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 9022, v011);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 9873, null);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 1915, v010);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 3940, v004);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 2686, v006);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 7928, v003);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 2053, v001);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 9093, v004);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 1786, v010);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 9038, v004);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 7025, v008);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 7253, null);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 3458, v001);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 8804, v005);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 2197, v011);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 8423, v009);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 8462, v000);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 1254, v006);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 2895, v005);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 2560, null);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 9257, v001);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 8474, null);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 3099, null);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 9670, v008);
        Tretja.Delavec d031 = new Tretja.Delavec("d031", 3265, v004);
        Tretja.Delavec d032 = new Tretja.Delavec("d032", 1187, null);
        Tretja.Delavec d033 = new Tretja.Delavec("d033", 2640, v007);
        Tretja.Delavec d034 = new Tretja.Delavec("d034", 5603, v005);
        Tretja.Delavec d035 = new Tretja.Delavec("d035", 9777, v002);
        Tretja.Delavec d036 = new Tretja.Delavec("d036", 5301, v010);
        Tretja.Delavec d037 = new Tretja.Delavec("d037", 8615, v003);
        Tretja.Delavec d038 = new Tretja.Delavec("d038", 2083, v007);
        Tretja.Delavec d039 = new Tretja.Delavec("d039", 9751, null);
        Tretja.Delavec d040 = new Tretja.Delavec("d040", 9505, null);
        Tretja.Delavec d041 = new Tretja.Delavec("d041", 4364, null);
        Tretja.Delavec d042 = new Tretja.Delavec("d042", 1294, v005);
        Tretja.Delavec d043 = new Tretja.Delavec("d043", 4012, v008);
        Tretja.Delavec d044 = new Tretja.Delavec("d044", 9339, v011);
        Tretja.Delavec d045 = new Tretja.Delavec("d045", 3192, null);
        Tretja.Delavec d046 = new Tretja.Delavec("d046", 6678, v003);
        Tretja.Delavec d047 = new Tretja.Delavec("d047", 8333, v002);
        Tretja.Delavec d048 = new Tretja.Delavec("d048", 1386, v010);
        Tretja.Delavec d049 = new Tretja.Delavec("d049", 6679, v005);
        Tretja.Delavec d050 = new Tretja.Delavec("d050", 3694, v005);
        Tretja.Delavec d051 = new Tretja.Delavec("d051", 1866, v005);
        Tretja.Delavec d052 = new Tretja.Delavec("d052", 2541, v002);
        Tretja.Delavec d053 = new Tretja.Delavec("d053", 5755, v001);
        Tretja.Delavec d054 = new Tretja.Delavec("d054", 7876, v001);
        Tretja.Delavec d055 = new Tretja.Delavec("d055", 5378, v007);
        Tretja.Delavec d056 = new Tretja.Delavec("d056", 4529, v009);
        Tretja.Delavec d057 = new Tretja.Delavec("d057", 8484, v008);
        Tretja.Delavec d058 = new Tretja.Delavec("d058", 7066, null);
        Tretja.Delavec d059 = new Tretja.Delavec("d059", 4436, v000);
        Tretja.Delavec d060 = new Tretja.Delavec("d060", 7894, v000);
        Tretja.Delavec d061 = new Tretja.Delavec("d061", 5003, v009);
        Tretja.Delavec d062 = new Tretja.Delavec("d062", 3122, v002);
        Tretja.Delavec d063 = new Tretja.Delavec("d063", 6021, v011);
        Tretja.Delavec d064 = new Tretja.Delavec("d064", 4818, v006);
        Tretja.Delavec d065 = new Tretja.Delavec("d065", 2977, v005);
        Tretja.Delavec d066 = new Tretja.Delavec("d066", 6068, v001);
        Tretja.Delavec d067 = new Tretja.Delavec("d067", 3722, v004);
        Tretja.Delavec d068 = new Tretja.Delavec("d068", 9076, v003);
        Tretja.Delavec d069 = new Tretja.Delavec("d069", 9887, v006);
        Tretja.Delavec d070 = new Tretja.Delavec("d070", 6476, v007);
        Tretja.Delavec d071 = new Tretja.Delavec("d071", 2826, v009);
        Tretja.Delavec d072 = new Tretja.Delavec("d072", 7657, v002);
        Tretja.Delavec d073 = new Tretja.Delavec("d073", 8433, v002);
        Tretja.Delavec d074 = new Tretja.Delavec("d074", 3823, v001);
        Tretja.Delavec d075 = new Tretja.Delavec("d075", 8288, v001);
        Tretja.Delavec d076 = new Tretja.Delavec("d076", 4366, v008);
        Tretja.Delavec d077 = new Tretja.Delavec("d077", 8683, null);
        Tretja.Delavec d078 = new Tretja.Delavec("d078", 4405, v000);
        Tretja.Delavec d079 = new Tretja.Delavec("d079", 6573, v008);
        Tretja.Delavec d080 = new Tretja.Delavec("d080", 5446, v006);

        Tretja.Zaposleni[] zaposleni = {
            v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011,
            d000, d001, d002, d003, d004, d005, d006, d007, d008, d009, d010, d011, d012, d013, d014, d015, d016, d017, d018, d019, d020, d021, d022, d023, d024, d025, d026, d027, d028, d029, d030, d031, d032, d033, d034, d035, d036, d037, d038, d039, d040, d041, d042, d043, d044, d045, d046, d047, d048, d049, d050, d051, d052, d053, d054, d055, d056, d057, d058, d059, d060, d061, d062, d063, d064, d065, d066, d067, d068, d069, d070, d071, d072, d073, d074, d075, d076, d077, d078, d079, d080
        };

        System.out.println("[ placaNadrejenega ]");
        for (Tretja.Zaposleni z: zaposleni) {
            System.out.printf("%s -> %d%n", z, z.placaNadrejenega());
        }
    }
}


public class Test28 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 8439, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 4934, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 9588, null);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 3798, null);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 5658, v000);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 1870, v001);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 9314, v002);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 3535, v002);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 8496, v005);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 1137, null);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 3798, v000);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 1733, v000);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 7023, v004);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 2402, v011);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 6041, v013);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 4692, v009);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 2564, null);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 3033, v016);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 3352, null);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 2642, v010);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 5612, v007);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 2884, v007);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 2147, v002);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 3231, v003);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 1015, null);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 1082, v015);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 3571, v020);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 8093, v012);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 5934, v002);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 6983, v005);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 2558, v009);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 2577, v020);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 5145, null);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 2218, v007);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 6474, v024);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 9788, v020);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 8271, v006);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 5479, v025);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 3974, v017);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 7448, v026);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 2469, v019);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 7975, v017);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 5986, v006);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 5636, v010);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 5653, null);
        Tretja.Vodja v045 = new Tretja.Vodja("v045", 2856, v014);
        Tretja.Vodja v046 = new Tretja.Vodja("v046", 6788, v045);
        Tretja.Vodja v047 = new Tretja.Vodja("v047", 4888, v040);
        Tretja.Vodja v048 = new Tretja.Vodja("v048", 4034, null);
        Tretja.Vodja v049 = new Tretja.Vodja("v049", 1908, v009);
        Tretja.Vodja v050 = new Tretja.Vodja("v050", 7924, v035);
        Tretja.Vodja v051 = new Tretja.Vodja("v051", 2894, v004);
        Tretja.Vodja v052 = new Tretja.Vodja("v052", 5232, null);
        Tretja.Vodja v053 = new Tretja.Vodja("v053", 2266, v020);
        Tretja.Vodja v054 = new Tretja.Vodja("v054", 8921, v001);
        Tretja.Vodja v055 = new Tretja.Vodja("v055", 4269, v026);
        Tretja.Vodja v056 = new Tretja.Vodja("v056", 1226, v040);
        Tretja.Vodja v057 = new Tretja.Vodja("v057", 6772, v002);
        Tretja.Vodja v058 = new Tretja.Vodja("v058", 7677, v033);
        Tretja.Vodja v059 = new Tretja.Vodja("v059", 3988, v037);
        Tretja.Vodja v060 = new Tretja.Vodja("v060", 8963, v045);
        Tretja.Vodja v061 = new Tretja.Vodja("v061", 3385, v027);
        Tretja.Vodja v062 = new Tretja.Vodja("v062", 9853, v041);
        Tretja.Vodja v063 = new Tretja.Vodja("v063", 1213, v050);
        Tretja.Vodja v064 = new Tretja.Vodja("v064", 4298, v000);
        Tretja.Vodja v065 = new Tretja.Vodja("v065", 1152, v041);
        Tretja.Vodja v066 = new Tretja.Vodja("v066", 7728, v037);
        Tretja.Vodja v067 = new Tretja.Vodja("v067", 7819, v025);
        Tretja.Vodja v068 = new Tretja.Vodja("v068", 1225, v022);
        Tretja.Vodja v069 = new Tretja.Vodja("v069", 3166, null);
        Tretja.Vodja v070 = new Tretja.Vodja("v070", 3760, v053);
        Tretja.Vodja v071 = new Tretja.Vodja("v071", 9399, null);
        Tretja.Vodja v072 = new Tretja.Vodja("v072", 9011, null);
        Tretja.Vodja v073 = new Tretja.Vodja("v073", 8303, v031);
        Tretja.Vodja v074 = new Tretja.Vodja("v074", 6209, v009);
        Tretja.Vodja v075 = new Tretja.Vodja("v075", 6826, v061);
        Tretja.Vodja v076 = new Tretja.Vodja("v076", 3765, v052);
        Tretja.Vodja v077 = new Tretja.Vodja("v077", 8296, v000);
        Tretja.Vodja v078 = new Tretja.Vodja("v078", 6007, null);
        Tretja.Vodja v079 = new Tretja.Vodja("v079", 1660, v041);
        Tretja.Vodja v080 = new Tretja.Vodja("v080", 2347, v054);
        Tretja.Vodja v081 = new Tretja.Vodja("v081", 8125, v003);
        Tretja.Vodja v082 = new Tretja.Vodja("v082", 7007, v055);
        Tretja.Vodja v083 = new Tretja.Vodja("v083", 7061, v056);

        Tretja.Vodja[] vodje = {v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043, v044, v045, v046, v047, v048, v049, v050, v051, v052, v053, v054, v055, v056, v057, v058, v059, v060, v061, v062, v063, v064, v065, v066, v067, v068, v069, v070, v071, v072, v073, v074, v075, v076, v077, v078, v079, v080, v081, v082, v083};

        System.out.println("[ vrhovni ]");
        for (Tretja.Vodja v: vodje) {
            System.out.printf("%s -> %s%n", v, v.vrhovni());
        }
    }
}

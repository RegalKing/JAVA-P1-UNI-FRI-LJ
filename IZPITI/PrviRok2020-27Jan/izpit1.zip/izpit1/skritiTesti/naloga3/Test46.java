
public class Test46 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 9631, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 2136, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 8664, null);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 2160, v001);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 6781, v000);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 4137, v003);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 9719, v000);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 3739, v000);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 9124, v006);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 9951, v005);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 5451, v001);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 3170, v009);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 3797, v004);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 6675, v011);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 8962, v012);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 7766, null);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 4980, v002);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 3038, null);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 3779, v001);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 3639, v012);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 7866, v011);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 8692, null);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 8183, v011);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 7845, v004);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 6972, v000);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 7185, v012);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 3318, v006);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 7860, v003);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 4330, v012);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 5618, v002);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 3163, null);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 9116, v010);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 5125, v010);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 5368, v008);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 6311, null);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 6473, v007);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 3297, v004);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 4099, v009);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 4525, v000);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 5760, v009);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 2314, v006);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 2030, v010);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 2427, v004);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 6516, v002);
        Tretja.Delavec d031 = new Tretja.Delavec("d031", 9302, v009);
        Tretja.Delavec d032 = new Tretja.Delavec("d032", 9700, v001);
        Tretja.Delavec d033 = new Tretja.Delavec("d033", 7732, v001);
        Tretja.Delavec d034 = new Tretja.Delavec("d034", 3134, v007);
        Tretja.Delavec d035 = new Tretja.Delavec("d035", 4978, v012);
        Tretja.Delavec d036 = new Tretja.Delavec("d036", 7878, v002);
        Tretja.Delavec d037 = new Tretja.Delavec("d037", 3914, null);
        Tretja.Delavec d038 = new Tretja.Delavec("d038", 4711, v006);
        Tretja.Delavec d039 = new Tretja.Delavec("d039", 1868, v009);
        Tretja.Delavec d040 = new Tretja.Delavec("d040", 9237, v004);
        Tretja.Delavec d041 = new Tretja.Delavec("d041", 6467, v002);
        Tretja.Delavec d042 = new Tretja.Delavec("d042", 5810, v006);
        Tretja.Delavec d043 = new Tretja.Delavec("d043", 3404, v007);
        Tretja.Delavec d044 = new Tretja.Delavec("d044", 5983, v010);
        Tretja.Delavec d045 = new Tretja.Delavec("d045", 5658, v012);
        Tretja.Delavec d046 = new Tretja.Delavec("d046", 9451, v005);
        Tretja.Delavec d047 = new Tretja.Delavec("d047", 8619, v009);
        Tretja.Delavec d048 = new Tretja.Delavec("d048", 5968, v001);
        Tretja.Delavec d049 = new Tretja.Delavec("d049", 5931, v008);
        Tretja.Delavec d050 = new Tretja.Delavec("d050", 6124, null);
        Tretja.Delavec d051 = new Tretja.Delavec("d051", 4215, v007);
        Tretja.Delavec d052 = new Tretja.Delavec("d052", 1262, v004);
        Tretja.Delavec d053 = new Tretja.Delavec("d053", 4871, v011);
        Tretja.Delavec d054 = new Tretja.Delavec("d054", 1034, null);
        Tretja.Delavec d055 = new Tretja.Delavec("d055", 5479, v008);
        Tretja.Delavec d056 = new Tretja.Delavec("d056", 2764, v006);
        Tretja.Delavec d057 = new Tretja.Delavec("d057", 9665, v009);
        Tretja.Delavec d058 = new Tretja.Delavec("d058", 8532, v007);
        Tretja.Delavec d059 = new Tretja.Delavec("d059", 2871, v003);
        Tretja.Delavec d060 = new Tretja.Delavec("d060", 6491, v006);
        Tretja.Delavec d061 = new Tretja.Delavec("d061", 4853, v001);
        Tretja.Delavec d062 = new Tretja.Delavec("d062", 9054, v009);
        Tretja.Delavec d063 = new Tretja.Delavec("d063", 6613, v009);
        Tretja.Delavec d064 = new Tretja.Delavec("d064", 8605, v002);
        Tretja.Delavec d065 = new Tretja.Delavec("d065", 5852, null);
        Tretja.Delavec d066 = new Tretja.Delavec("d066", 6844, v010);
        Tretja.Delavec d067 = new Tretja.Delavec("d067", 2020, v002);

        Tretja.Zaposleni[] zaposleni = {d037, d005, d059, d033, d006, d013, v007, d043, d038, d064, d024, d066, d046, d004, d000, d012, v006, d022, d031, d040, d052, d035, d042, d060, d018, v002, d003, d028, v012, d056, d027, d015, d054, d051, d009, d049, d065, d036, d029, v009, d001, d007, d058, d039, d063, d062, d026, d044, d021, d011, d067, d002, v011, v004, d061, d020, d053, d017, d023, v010, d055, d014, d016, d030, d034, v005, d050, d041, d047, d048, v000, d045, d032, d025, d010, v008, v003, v001, d057, d019, d008};

        System.out.printf("steviloAnomalij = %d%n", Tretja.Zaposleni.steviloAnomalij(zaposleni));
    }
}


public class Test06 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 7649, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 2778, v000);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 9472, v000);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 8764, null);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 2903, null);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 9523, v000);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 2852, v000);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 9519, null);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 1693, v007);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 9840, v006);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 4698, v001);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 4212, v008);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 1239, v010);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 8705, v012);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 7478, v013);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 2928, v007);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 3817, v013);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 7872, v016);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 8358, v009);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 2970, v014);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 4831, v011);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 5712, v020);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 8438, v017);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 8103, v002);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 5065, null);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 6765, v003);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 2349, v014);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 1281, v000);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 6578, v020);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 6642, v027);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 6255, v002);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 6136, null);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 7404, v023);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 1194, null);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 1154, v010);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 2508, v030);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 8130, v031);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 7769, v020);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 9269, v021);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 9587, v033);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 1331, v036);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 9305, v001);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 2720, v031);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 8988, v016);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 4053, v001);
        Tretja.Vodja v045 = new Tretja.Vodja("v045", 7173, v033);
        Tretja.Vodja v046 = new Tretja.Vodja("v046", 8140, v009);
        Tretja.Vodja v047 = new Tretja.Vodja("v047", 3557, v041);
        Tretja.Vodja v048 = new Tretja.Vodja("v048", 4059, v001);
        Tretja.Vodja v049 = new Tretja.Vodja("v049", 6642, v021);
        Tretja.Vodja v050 = new Tretja.Vodja("v050", 5242, v033);
        Tretja.Vodja v051 = new Tretja.Vodja("v051", 9114, v049);
        Tretja.Vodja v052 = new Tretja.Vodja("v052", 5015, v040);
        Tretja.Vodja v053 = new Tretja.Vodja("v053", 9014, v003);
        Tretja.Vodja v054 = new Tretja.Vodja("v054", 4041, v027);
        Tretja.Vodja v055 = new Tretja.Vodja("v055", 2842, v054);
        Tretja.Vodja v056 = new Tretja.Vodja("v056", 6146, v004);
        Tretja.Vodja v057 = new Tretja.Vodja("v057", 3378, v046);
        Tretja.Vodja v058 = new Tretja.Vodja("v058", 9022, null);
        Tretja.Vodja v059 = new Tretja.Vodja("v059", 3387, v043);
        Tretja.Vodja v060 = new Tretja.Vodja("v060", 9651, v048);
        Tretja.Vodja v061 = new Tretja.Vodja("v061", 4581, v050);
        Tretja.Vodja v062 = new Tretja.Vodja("v062", 1206, v015);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 8146, v008);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 9586, v055);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 2097, v030);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 7004, v034);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 5128, null);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 7989, null);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 8265, v023);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 5542, v030);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 5579, v018);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 7390, null);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 7795, v002);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 3365, v021);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 9446, null);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 3083, v046);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 3302, null);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 6341, v042);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 5692, v036);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 6025, v036);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 6362, v034);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 7675, v014);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 1284, v020);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 3731, v036);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 8175, v003);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 7216, v037);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 1968, v013);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 8582, v020);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 2051, v021);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 6299, v056);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 6096, v038);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 1237, v015);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 7575, null);
        Tretja.Delavec d031 = new Tretja.Delavec("d031", 2109, null);
        Tretja.Delavec d032 = new Tretja.Delavec("d032", 6105, v040);
        Tretja.Delavec d033 = new Tretja.Delavec("d033", 2389, v059);
        Tretja.Delavec d034 = new Tretja.Delavec("d034", 2518, null);
        Tretja.Delavec d035 = new Tretja.Delavec("d035", 7356, v017);
        Tretja.Delavec d036 = new Tretja.Delavec("d036", 4950, v052);
        Tretja.Delavec d037 = new Tretja.Delavec("d037", 1192, v022);
        Tretja.Delavec d038 = new Tretja.Delavec("d038", 1789, null);
        Tretja.Delavec d039 = new Tretja.Delavec("d039", 2071, v049);
        Tretja.Delavec d040 = new Tretja.Delavec("d040", 8562, null);
        Tretja.Delavec d041 = new Tretja.Delavec("d041", 5657, v041);
        Tretja.Delavec d042 = new Tretja.Delavec("d042", 8123, v023);
        Tretja.Delavec d043 = new Tretja.Delavec("d043", 6990, v020);
        Tretja.Delavec d044 = new Tretja.Delavec("d044", 8487, v049);
        Tretja.Delavec d045 = new Tretja.Delavec("d045", 4940, v024);
        Tretja.Delavec d046 = new Tretja.Delavec("d046", 7669, v037);
        Tretja.Delavec d047 = new Tretja.Delavec("d047", 6627, v040);
        Tretja.Delavec d048 = new Tretja.Delavec("d048", 8468, null);
        Tretja.Delavec d049 = new Tretja.Delavec("d049", 7381, null);
        Tretja.Delavec d050 = new Tretja.Delavec("d050", 5977, v015);
        Tretja.Delavec d051 = new Tretja.Delavec("d051", 2809, null);
        Tretja.Delavec d052 = new Tretja.Delavec("d052", 4382, v016);
        Tretja.Delavec d053 = new Tretja.Delavec("d053", 6528, v056);
        Tretja.Delavec d054 = new Tretja.Delavec("d054", 1464, v016);
        Tretja.Delavec d055 = new Tretja.Delavec("d055", 3308, null);

        Tretja.Zaposleni[] zaposleni = {
            v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043, v044, v045, v046, v047, v048, v049, v050, v051, v052, v053, v054, v055, v056, v057, v058, v059, v060, v061, v062,
            d000, d001, d002, d003, d004, d005, d006, d007, d008, d009, d010, d011, d012, d013, d014, d015, d016, d017, d018, d019, d020, d021, d022, d023, d024, d025, d026, d027, d028, d029, d030, d031, d032, d033, d034, d035, d036, d037, d038, d039, d040, d041, d042, d043, d044, d045, d046, d047, d048, d049, d050, d051, d052, d053, d054, d055
        };

        System.out.println("[ placaNadrejenega ]");
        for (Tretja.Zaposleni z: zaposleni) {
            System.out.printf("%s -> %d%n", z, z.placaNadrejenega());
        }
    }
}

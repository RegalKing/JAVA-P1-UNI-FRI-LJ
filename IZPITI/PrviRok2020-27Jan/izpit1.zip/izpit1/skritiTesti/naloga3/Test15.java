
public class Test15 {

    public static void main(String[] args) {
        Tretja.Vodja v000 = new Tretja.Vodja("v000", 1093, null);
        Tretja.Vodja v001 = new Tretja.Vodja("v001", 4593, null);
        Tretja.Vodja v002 = new Tretja.Vodja("v002", 7910, v000);
        Tretja.Vodja v003 = new Tretja.Vodja("v003", 7591, v001);
        Tretja.Vodja v004 = new Tretja.Vodja("v004", 6800, v001);
        Tretja.Vodja v005 = new Tretja.Vodja("v005", 4310, v001);
        Tretja.Vodja v006 = new Tretja.Vodja("v006", 2332, v005);
        Tretja.Vodja v007 = new Tretja.Vodja("v007", 1021, null);
        Tretja.Vodja v008 = new Tretja.Vodja("v008", 6376, v005);
        Tretja.Vodja v009 = new Tretja.Vodja("v009", 6749, v003);
        Tretja.Vodja v010 = new Tretja.Vodja("v010", 4695, v000);
        Tretja.Vodja v011 = new Tretja.Vodja("v011", 7401, v007);
        Tretja.Vodja v012 = new Tretja.Vodja("v012", 4883, v002);
        Tretja.Vodja v013 = new Tretja.Vodja("v013", 3558, v009);
        Tretja.Vodja v014 = new Tretja.Vodja("v014", 5006, v006);
        Tretja.Vodja v015 = new Tretja.Vodja("v015", 4565, v004);
        Tretja.Vodja v016 = new Tretja.Vodja("v016", 5776, v006);
        Tretja.Vodja v017 = new Tretja.Vodja("v017", 7305, v010);
        Tretja.Vodja v018 = new Tretja.Vodja("v018", 4278, v007);
        Tretja.Vodja v019 = new Tretja.Vodja("v019", 4454, v018);
        Tretja.Vodja v020 = new Tretja.Vodja("v020", 7294, v014);
        Tretja.Vodja v021 = new Tretja.Vodja("v021", 2327, v017);
        Tretja.Vodja v022 = new Tretja.Vodja("v022", 4422, v009);
        Tretja.Vodja v023 = new Tretja.Vodja("v023", 1088, v021);
        Tretja.Vodja v024 = new Tretja.Vodja("v024", 4789, v005);
        Tretja.Vodja v025 = new Tretja.Vodja("v025", 9668, null);
        Tretja.Vodja v026 = new Tretja.Vodja("v026", 6977, v011);
        Tretja.Vodja v027 = new Tretja.Vodja("v027", 1890, v025);
        Tretja.Vodja v028 = new Tretja.Vodja("v028", 9103, null);
        Tretja.Vodja v029 = new Tretja.Vodja("v029", 1503, null);
        Tretja.Vodja v030 = new Tretja.Vodja("v030", 4470, v026);
        Tretja.Vodja v031 = new Tretja.Vodja("v031", 2723, v030);
        Tretja.Vodja v032 = new Tretja.Vodja("v032", 2027, v006);
        Tretja.Vodja v033 = new Tretja.Vodja("v033", 9861, null);
        Tretja.Vodja v034 = new Tretja.Vodja("v034", 5914, v025);
        Tretja.Vodja v035 = new Tretja.Vodja("v035", 5977, v015);
        Tretja.Vodja v036 = new Tretja.Vodja("v036", 6954, v004);
        Tretja.Vodja v037 = new Tretja.Vodja("v037", 8918, null);
        Tretja.Vodja v038 = new Tretja.Vodja("v038", 4972, v032);
        Tretja.Vodja v039 = new Tretja.Vodja("v039", 3110, v021);
        Tretja.Vodja v040 = new Tretja.Vodja("v040", 8289, null);
        Tretja.Vodja v041 = new Tretja.Vodja("v041", 3354, v036);
        Tretja.Vodja v042 = new Tretja.Vodja("v042", 1591, v021);
        Tretja.Vodja v043 = new Tretja.Vodja("v043", 7867, null);
        Tretja.Vodja v044 = new Tretja.Vodja("v044", 6427, v037);
        Tretja.Vodja v045 = new Tretja.Vodja("v045", 5095, v040);
        Tretja.Vodja v046 = new Tretja.Vodja("v046", 7634, v013);
        Tretja.Vodja v047 = new Tretja.Vodja("v047", 5798, null);
        Tretja.Vodja v048 = new Tretja.Vodja("v048", 8203, null);
        Tretja.Vodja v049 = new Tretja.Vodja("v049", 4372, v000);
        Tretja.Vodja v050 = new Tretja.Vodja("v050", 5930, v016);
        Tretja.Vodja v051 = new Tretja.Vodja("v051", 1616, null);
        Tretja.Vodja v052 = new Tretja.Vodja("v052", 1340, v001);
        Tretja.Vodja v053 = new Tretja.Vodja("v053", 6594, v052);
        Tretja.Vodja v054 = new Tretja.Vodja("v054", 4470, v014);
        Tretja.Vodja v055 = new Tretja.Vodja("v055", 7039, null);
        Tretja.Vodja v056 = new Tretja.Vodja("v056", 7602, v034);
        Tretja.Vodja v057 = new Tretja.Vodja("v057", 4515, v020);
        Tretja.Vodja v058 = new Tretja.Vodja("v058", 2381, v041);
        Tretja.Vodja v059 = new Tretja.Vodja("v059", 6073, v001);
        Tretja.Vodja v060 = new Tretja.Vodja("v060", 8289, v058);
        Tretja.Vodja v061 = new Tretja.Vodja("v061", 2966, v010);
        Tretja.Vodja v062 = new Tretja.Vodja("v062", 9164, v050);
        Tretja.Vodja v063 = new Tretja.Vodja("v063", 4034, v053);
        Tretja.Vodja v064 = new Tretja.Vodja("v064", 2683, v004);
        Tretja.Vodja v065 = new Tretja.Vodja("v065", 2604, null);
        Tretja.Vodja v066 = new Tretja.Vodja("v066", 5023, v058);
        Tretja.Vodja v067 = new Tretja.Vodja("v067", 5267, v003);

        Tretja.Delavec d000 = new Tretja.Delavec("d000", 9115, v011);
        Tretja.Delavec d001 = new Tretja.Delavec("d001", 9493, v065);
        Tretja.Delavec d002 = new Tretja.Delavec("d002", 3814, v008);
        Tretja.Delavec d003 = new Tretja.Delavec("d003", 2845, v030);
        Tretja.Delavec d004 = new Tretja.Delavec("d004", 3655, v034);
        Tretja.Delavec d005 = new Tretja.Delavec("d005", 1283, v009);
        Tretja.Delavec d006 = new Tretja.Delavec("d006", 4362, null);
        Tretja.Delavec d007 = new Tretja.Delavec("d007", 1827, v020);
        Tretja.Delavec d008 = new Tretja.Delavec("d008", 5355, v066);
        Tretja.Delavec d009 = new Tretja.Delavec("d009", 9315, null);
        Tretja.Delavec d010 = new Tretja.Delavec("d010", 4200, v021);
        Tretja.Delavec d011 = new Tretja.Delavec("d011", 7728, v053);
        Tretja.Delavec d012 = new Tretja.Delavec("d012", 8426, v064);
        Tretja.Delavec d013 = new Tretja.Delavec("d013", 4859, null);
        Tretja.Delavec d014 = new Tretja.Delavec("d014", 6273, v030);
        Tretja.Delavec d015 = new Tretja.Delavec("d015", 7444, v048);
        Tretja.Delavec d016 = new Tretja.Delavec("d016", 7236, v049);
        Tretja.Delavec d017 = new Tretja.Delavec("d017", 6697, v025);
        Tretja.Delavec d018 = new Tretja.Delavec("d018", 7694, v007);
        Tretja.Delavec d019 = new Tretja.Delavec("d019", 5783, v065);
        Tretja.Delavec d020 = new Tretja.Delavec("d020", 2318, v002);
        Tretja.Delavec d021 = new Tretja.Delavec("d021", 8814, v048);
        Tretja.Delavec d022 = new Tretja.Delavec("d022", 2953, v042);
        Tretja.Delavec d023 = new Tretja.Delavec("d023", 4662, v018);
        Tretja.Delavec d024 = new Tretja.Delavec("d024", 9193, v001);
        Tretja.Delavec d025 = new Tretja.Delavec("d025", 2687, null);
        Tretja.Delavec d026 = new Tretja.Delavec("d026", 2036, v000);
        Tretja.Delavec d027 = new Tretja.Delavec("d027", 5917, v038);
        Tretja.Delavec d028 = new Tretja.Delavec("d028", 5169, v063);
        Tretja.Delavec d029 = new Tretja.Delavec("d029", 1077, v034);
        Tretja.Delavec d030 = new Tretja.Delavec("d030", 4535, v056);
        Tretja.Delavec d031 = new Tretja.Delavec("d031", 8954, null);
        Tretja.Delavec d032 = new Tretja.Delavec("d032", 8465, v042);
        Tretja.Delavec d033 = new Tretja.Delavec("d033", 3101, null);
        Tretja.Delavec d034 = new Tretja.Delavec("d034", 7282, v015);
        Tretja.Delavec d035 = new Tretja.Delavec("d035", 8809, v060);
        Tretja.Delavec d036 = new Tretja.Delavec("d036", 9306, v017);
        Tretja.Delavec d037 = new Tretja.Delavec("d037", 9000, v000);
        Tretja.Delavec d038 = new Tretja.Delavec("d038", 6442, v046);
        Tretja.Delavec d039 = new Tretja.Delavec("d039", 2455, v029);
        Tretja.Delavec d040 = new Tretja.Delavec("d040", 5118, v029);
        Tretja.Delavec d041 = new Tretja.Delavec("d041", 6823, v027);
        Tretja.Delavec d042 = new Tretja.Delavec("d042", 2604, v025);
        Tretja.Delavec d043 = new Tretja.Delavec("d043", 3980, v066);
        Tretja.Delavec d044 = new Tretja.Delavec("d044", 9658, null);
        Tretja.Delavec d045 = new Tretja.Delavec("d045", 8286, v050);
        Tretja.Delavec d046 = new Tretja.Delavec("d046", 6409, v034);
        Tretja.Delavec d047 = new Tretja.Delavec("d047", 9718, v011);
        Tretja.Delavec d048 = new Tretja.Delavec("d048", 9614, v055);
        Tretja.Delavec d049 = new Tretja.Delavec("d049", 4640, v011);

        Tretja.Zaposleni[] zaposleni = {
            v000, v001, v002, v003, v004, v005, v006, v007, v008, v009, v010, v011, v012, v013, v014, v015, v016, v017, v018, v019, v020, v021, v022, v023, v024, v025, v026, v027, v028, v029, v030, v031, v032, v033, v034, v035, v036, v037, v038, v039, v040, v041, v042, v043, v044, v045, v046, v047, v048, v049, v050, v051, v052, v053, v054, v055, v056, v057, v058, v059, v060, v061, v062, v063, v064, v065, v066, v067,
            d000, d001, d002, d003, d004, d005, d006, d007, d008, d009, d010, d011, d012, d013, d014, d015, d016, d017, d018, d019, d020, d021, d022, d023, d024, d025, d026, d027, d028, d029, d030, d031, d032, d033, d034, d035, d036, d037, d038, d039, d040, d041, d042, d043, d044, d045, d046, d047, d048, d049
        };

        System.out.println("[ placaNadrejenega ]");
        for (Tretja.Zaposleni z: zaposleni) {
            System.out.printf("%s -> %d%n", z, z.placaNadrejenega());
        }
    }
}


import java.util.*;

public class Druga {

    public static void main(String[] args) {
        // dopolnite ...
    }
}

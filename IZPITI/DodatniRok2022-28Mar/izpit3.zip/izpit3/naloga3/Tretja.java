
import java.util.*;

public class Tretja {

    public static class Oddajnik {
        // dopolnite ...
    }

    public static class Sprejemnik {
        // dopolnite ...
    }

    public static void main(String[] args) {
        // koda za ro"cno testiranje (po potrebi)
    }
}
